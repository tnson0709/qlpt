import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Plus, 
  Search, 
  Edit, 
  Copy, 
  Trash2,
  Users,
  UserCheck,
  UserX,
  Phone
} from "lucide-react";

import { db } from "@/lib/db";
import { exportToXlsx, importFromXlsx } from "@/lib/excel";
import { toast } from "@/hooks/use-toast";

interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  idNumber: string;
  address: string;
  roomNumber?: string;
  status: "active" | "inactive" | "pending";
  depositAmount: number;
  startDate?: string;
  endDate?: string;
}

const mockCustomers: Customer[] = [
  {
    id: "1",
    name: "Nguyễn Văn A",
    phone: "0123456789",
    email: "nguyenvana@email.com",
    idNumber: "123456789",
    address: "456 Đường XYZ, Quận 2",
    roomNumber: "P101",
    status: "active",
    depositAmount: 7000000,
    startDate: "2024-01-01",
    endDate: "2024-12-31"
  },
  {
    id: "2",
    name: "Trần Thị B", 
    phone: "0987654321",
    email: "tranthib@email.com",
    idNumber: "987654321",
    address: "789 Đường DEF, Quận 3",
    roomNumber: "P201",
    status: "active",
    depositAmount: 8000000,
    startDate: "2024-02-01",
    endDate: "2024-12-31"
  },
  {
    id: "3",
    name: "Lê Văn C",
    phone: "0345678901",
    email: "levanc@email.com", 
    idNumber: "345678901",
    address: "321 Đường GHI, Quận 4",
    status: "pending",
    depositAmount: 3500000
  }
];

export default function Customers() {
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers);
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    db.customers.toArray().then(async (rows) => {
      if (rows.length > 0) {
        setCustomers(rows as Customer[]);
      } else {
        await db.customers.bulkAdd(mockCustomers as Customer[]);
        setCustomers(mockCustomers);
      }
    }).catch(console.error);
  }, []);

  const handleExport = () => {
    exportToXlsx({ filename: 'customers.xlsx', data: customers });
  };

  const handleImport = async (file: File) => {
    try {
      const rows = await importFromXlsx(file);
      const mapped: Customer[] = rows.map((r: any, idx: number) => ({
        id: String(r.id || `${Date.now()}_${idx}`),
        name: String(r.name || ''),
        phone: String(r.phone || ''),
        email: String(r.email || ''),
        idNumber: String(r.idNumber || ''),
        address: String(r.address || ''),
        roomNumber: r.roomNumber ? String(r.roomNumber) : undefined,
        status: (r.status as Customer["status"]) || 'pending',
        depositAmount: Number(r.depositAmount || 0),
        startDate: r.startDate ? String(r.startDate) : undefined,
        endDate: r.endDate ? String(r.endDate) : undefined,
      }));
      await db.customers.clear();
      if (mapped.length) await db.customers.bulkAdd(mapped);
      setCustomers(mapped);
      toast({ title: 'Nhập Excel thành công', description: `Đã nhập ${mapped.length} khách hàng` });
    } catch {
      toast({ title: 'Nhập Excel thất bại', description: 'Vui lòng kiểm tra file', variant: 'destructive' as any });
    }
  };

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm) ||
    customer.roomNumber?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: Customer["status"]) => {
    switch (status) {
      case "active":
        return <Badge variant="secondary">Đang thuê</Badge>;
      case "inactive":
        return <Badge variant="outline">Ngừng thuê</Badge>;
      case "pending":
        return <Badge variant="destructive">Chờ xử lý</Badge>;
    }
  };

  const handleAddCustomer = () => {
    setEditingCustomer(null);
    setIsDialogOpen(true);
  };

  const handleEditCustomer = (customer: Customer) => {
    setEditingCustomer(customer);
    setIsDialogOpen(true);
  };

  const handleCopyCustomer = async (customer: Customer) => {
    const newCustomer: Customer = {
      ...customer,
      id: Date.now().toString(),
      name: `${customer.name} (Copy)`,
      phone: "",
      email: "",
      idNumber: "",
      roomNumber: undefined,
      status: "pending",
    };
    await db.customers.add(newCustomer);
    setCustomers([...customers, newCustomer]);
    toast({ title: 'Đã nhân bản khách hàng', description: newCustomer.name });
  };

  const handleDeleteCustomer = async (customerId: string) => {
    await db.customers.delete(customerId);
    setCustomers(customers.filter(customer => customer.id !== customerId));
    toast({ title: 'Đã xóa khách hàng' });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Quản lý khách hàng</h1>
          <p className="text-muted-foreground mt-2">
            Quản lý thông tin khách thuê phòng
          </p>
        </div>
        <Button onClick={handleAddCustomer} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Thêm khách hàng
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{customers.length}</p>
                <p className="text-muted-foreground text-sm">Tổng khách hàng</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <UserCheck className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {customers.filter(c => c.status === "active").length}
                </p>
                <p className="text-muted-foreground text-sm">Đang thuê</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <UserX className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {customers.filter(c => c.status === "pending").length}
                </p>
                <p className="text-muted-foreground text-sm">Chờ xử lý</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Danh sách khách hàng</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Tìm kiếm khách hàng..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tên khách hàng</TableHead>
                  <TableHead>Số điện thoại</TableHead>
                  <TableHead>Phòng</TableHead>
                  <TableHead>Đặt cọc</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead className="text-right">Thao tác</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCustomers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell className="font-medium">{customer.name}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        {customer.phone}
                      </div>
                    </TableCell>
                    <TableCell>{customer.roomNumber || "-"}</TableCell>
                    <TableCell>{formatCurrency(customer.depositAmount)}</TableCell>
                    <TableCell>{getStatusBadge(customer.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditCustomer(customer)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyCustomer(customer)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteCustomer(customer.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Customer Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCustomer ? "Chỉnh sửa khách hàng" : "Thêm khách hàng mới"}
            </DialogTitle>
          </DialogHeader>
          <CustomerForm 
            customer={editingCustomer} 
            onSave={(customer) => {
              if (editingCustomer) {
                setCustomers(customers.map(c => c.id === editingCustomer.id ? customer : c));
              } else {
                setCustomers([...customers, { ...customer, id: Date.now().toString() }]);
              }
              setIsDialogOpen(false);
            }}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface CustomerFormProps {
  customer?: Customer | null;
  onSave: (customer: Customer) => void;
  onCancel: () => void;
}

function CustomerForm({ customer, onSave, onCancel }: CustomerFormProps) {
  const [formData, setFormData] = useState<Partial<Customer>>({
    name: customer?.name || "",
    phone: customer?.phone || "",
    email: customer?.email || "",
    idNumber: customer?.idNumber || "",
    address: customer?.address || "",
    roomNumber: customer?.roomNumber || "",
    status: customer?.status || "pending",
    depositAmount: customer?.depositAmount || 0,
    startDate: customer?.startDate || "",
    endDate: customer?.endDate || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Customer);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Tên khách hàng</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Nguyễn Văn A"
            required
          />
        </div>
        <div>
          <Label htmlFor="phone">Số điện thoại</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="0123456789"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="example@email.com"
          />
        </div>
        <div>
          <Label htmlFor="idNumber">CMND/CCCD</Label>
          <Input
            id="idNumber"
            value={formData.idNumber}
            onChange={(e) => setFormData({ ...formData, idNumber: e.target.value })}
            placeholder="123456789"
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="address">Địa chỉ</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="123 Đường ABC, Quận 1"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="roomNumber">Phòng</Label>
          <Input
            id="roomNumber"
            value={formData.roomNumber}
            onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
            placeholder="P101"
          />
        </div>
        <div>
          <Label htmlFor="status">Trạng thái</Label>
          <select
            id="status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as Customer["status"] })}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
          >
            <option value="pending">Chờ xử lý</option>
            <option value="active">Đang thuê</option>
            <option value="inactive">Ngừng thuê</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="startDate">Ngày bắt đầu</Label>
          <Input
            id="startDate"
            type="date"
            value={formData.startDate}
            onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
          />
        </div>
        <div>
          <Label htmlFor="endDate">Ngày kết thúc</Label>
          <Input
            id="endDate"
            type="date"
            value={formData.endDate}
            onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
          />
        </div>
      </div>

      <div>
        <Label htmlFor="depositAmount">Số tiền đặt cọc (VNĐ)</Label>
        <Input
          id="depositAmount"
          type="number"
          value={formData.depositAmount}
          onChange={(e) => setFormData({ ...formData, depositAmount: Number(e.target.value) })}
          placeholder="7000000"
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Hủy
        </Button>
        <Button type="submit">
          {customer ? "Cập nhật" : "Thêm"}
        </Button>
      </div>
    </form>
  );
}