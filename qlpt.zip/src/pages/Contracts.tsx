import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Plus,
  Search,
  Edit,
  Copy,
  Trash2,
  FileText,
  Calendar,
  AlertTriangle,
  CheckCircle,
} from "lucide-react";
import { format } from "date-fns";
import { json } from "stream/consumers";
import { stringify } from "querystring";
//import QRCode from "qrcode.react"; // Add QR code import

interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
}

interface Room {
  id: string;
  number: string;
  floor: string;
  type: string;
}

interface Contract {
  id: string;
  contractNumber: string;
  customerName: string;
  roomNumber: string;
  startDate: string;
  endDate: string;
  rentPrice: number;
  depositAmount: number;
  status: "active" | "expired" | "terminated" | "pending";
  terms: string;
  createdDate: string;
  electricPrice: number;
  waterPrice: number;
  otherFees: number;
  customerId: string;
  roomId: string;
}

const mockCustomers: Customer[] = [
  { id: "1", name: "Nguyễn Văn A", phone: "0901234567", email: "nva@email.com" },
  { id: "2", name: "Trần Thị B", phone: "0901234568", email: "ttb@email.com" },
  { id: "3", name: "Lê Văn C", phone: "0901234569", email: "lvc@email.com" },
];

const mockRooms: Room[] = [
  { id: "1", number: "P101", floor: "1", type: "Standard" },
  { id: "2", number: "P201", floor: "2", type: "Deluxe" },
  { id: "3", number: "P102", floor: "1", type: "Standard" },
];

const mockContracts: Contract[] = [
  {
    id: "1",
    contractNumber: "HD001",
    customerName: "Nguyễn Văn A",
    roomNumber: "P101",
    startDate: "2024-01-01",
    endDate: "2024-12-31",
    rentPrice: 3500000,
    depositAmount: 7000000,
    status: "active",
    terms: "Thanh toán tiền thuê vào ngày 5 hàng tháng. Không được nuôi thú cưng.",
    createdDate: "2023-12-15",
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 100000,
    customerId: "1",
    roomId: "1",
  },
  {
    id: "2",
    contractNumber: "HD002",
    customerName: "Trần Thị B",
    roomNumber: "P201",
    startDate: "2024-02-01",
    endDate: "2024-12-31",
    rentPrice: 4000000,
    depositAmount: 8000000,
    status: "active",
    terms: "Thanh toán tiền thuê vào ngày 1 hàng tháng. Được phép nấu ăn.",
    createdDate: "2024-01-20",
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 150000,
    customerId: "2",
    roomId: "2",
  },
  {
    id: "3",
    contractNumber: "HD003",
    customerName: "Lê Văn C",
    roomNumber: "P102",
    startDate: "2023-06-01",
    endDate: "2024-05-31",
    rentPrice: 3500000,
    depositAmount: 7000000,
    status: "expired",
    terms: "Hợp đồng 12 tháng. Không hút thuốc trong phòng.",
    createdDate: "2023-05-15",
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 100000,
    customerId: "3",
    roomId: "3",
  },
];

export default function Contracts() {
  const [contracts, setContracts] = useState<Contract[]>(mockContracts);
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContract, setEditingContract] = useState<Contract | null>(null);
  const [isReceiptDialogOpen, setIsReceiptDialogOpen] = useState(false);
  const [usageInputs, setUsageInputs] = useState<
    Record<
      string,
      {
        electric: number;
        water: number;
        internet: number;
        service: number;
        other: number;
        debt: number;
        tierElectric: boolean;
        tierWater: boolean;
      }
    >
  >({});

  const filteredContracts = contracts.filter(
    (contract) =>
      contract.contractNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.roomNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: Contract["status"]) => {
    switch (status) {
      case "active":
        return <Badge variant="secondary">Đang hiệu lực</Badge>;
      case "expired":
        return <Badge variant="destructive">Hết hạn</Badge>;
      case "terminated":
        return <Badge variant="outline">Đã chấm dứt</Badge>;
      case "pending":
        return (
          <Badge className="bg-warning text-warning-foreground">Chờ ký</Badge>
        );
    }
  };

  const handleAddContract = () => {
    setEditingContract(null);
    setIsDialogOpen(true);
  };

  const handleEditContract = (contract: Contract) => {
    setEditingContract(contract);
    setIsDialogOpen(true);
  };

  const handleCopyContract = (contract: Contract) => {
    const newContract = {
      ...contract,
      id: Date.now().toString(),
      contractNumber: `${contract.contractNumber}_Copy`,
      status: "pending" as const,
      createdDate: new Date().toISOString().split("T")[0],
    };
    setContracts([...contracts, newContract]);
  };

  const handleDeleteContract = (contractId: string) => {
    setContracts(contracts.filter((contract) => contract.id !== contractId));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("vi-VN");
  };

  const getContractDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    const diffTime = end.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  // Helper: Calculate tiered price (simple example, you can expand logic)
  const calcTieredPrice = (
    usage: number,
    base: number,
    type: "electric" | "water"
  ) => {
    if (type === "electric") {
      // Example: first 50 kWh: base, next 50: base*1.2, rest: base*1.5
      if (usage <= 50) return usage * base;
      if (usage <= 100) return 50 * base + (usage - 50) * base * 1.2;
      return 50 * base + 50 * base * 1.2 + (usage - 100) * base * 1.5;
    }
    if (type === "water") {
      // Example: first 10 m3: base, next 10: base*1.1, rest: base*1.3
      if (usage <= 10) return usage * base;
      if (usage <= 20) return 10 * base + (usage - 10) * base * 1.1;
      return 10 * base + 10 * base * 1.1 + (usage - 20) * base * 1.3;
    }
    return usage * base;
  };

  // Helper: Calculate total for a contract
  const calcTotal = (
    contract: Contract,
    usage: typeof usageInputs[string]
  ) => {
    const electric = usage.tierElectric
      ? calcTieredPrice(usage.electric, contract.electricPrice, "electric")
      : usage.electric * contract.electricPrice;
    const water = usage.tierWater
      ? calcTieredPrice(usage.water, contract.waterPrice, "water")
      : usage.water * contract.waterPrice;
    const internet = usage.internet || 0;
    const service = usage.service || 0;
    const other = usage.other || contract.otherFees || 0;
    const room = contract.rentPrice;
    const debt = usage.debt || 0;
    const total = room + electric + water + internet + service + other + debt;
    return { room, electric, water, internet, service, other, debt, total };
  };

  // Sinh phiếu thu cho tất cả hợp đồng đang hiệu lực
  const handleCreateReceipts = () => {
    const today = new Date();
    const month = today.getMonth() ; // Tháng hiện tại (1-12)
    const year = today.getFullYear(); // Năm hiện tại
    const receipts: any[] = [];
    contracts
      .filter((c) => c.status === "active")
      .forEach((contract) => {
        receipts.push({
          id: today.getTime() + contract.id ,
          type: "income",
          category: "Tiền thuê phòng",
          amount: contract.rentPrice,
          description: `Tiền thuê phòng ${contract.roomNumber} tháng ${month}/${year}`,
          date: format(today, "yyyy-MM-dd"),
          customerName: contract.customerName,
          roomNumber: contract.roomNumber,
          paymentMethod: "cash",
          status: "pending",
          receiptNumber: "PT_TP_" + today.getTime() ,
        });
        receipts.push({
          id: today.getTime() + contract.id ,
          type: "income",
          category: "Tiền điện",
          amount: contract.electricPrice,
          description: `Tiền điện phòng ${contract.roomNumber} tháng ${month}/${year}`,
          date: format(today, "yyyy-MM-dd"),
          customerName: contract.customerName,
          roomNumber: contract.roomNumber,
          paymentMethod: "cash",
          status: "pending",
          receiptNumber: "PT_TD_" + today.getTime() ,
        });
        receipts.push({
          id: today.getTime() + contract.id ,
          type: "income",
          category: "Tiền nước",
          amount: contract.waterPrice,
          description: `Tiền nước phòng ${contract.roomNumber} tháng ${month}/${year}`,
          date: format(today, "yyyy-MM-dd"),
          customerName: contract.customerName,
          roomNumber: contract.roomNumber,
          paymentMethod: "cash",
          status: "pending",
          receiptNumber: "PT_TN_" + today.getTime() ,
        });
        receipts.push({
          id: today.getTime() + contract.id ,
          type: "income",
          category: "Phí khác",
          amount: contract.otherFees,
          description: `Phí khác phòng ${contract.roomNumber} tháng ${month}/${year}`,
          date: format(today, "yyyy-MM-dd"),
          customerName: contract.customerName,
          roomNumber: contract.roomNumber,
          paymentMethod: "cash",
          status: "pending",
          receiptNumber: "PT_TK_" + today.getTime() ,
        });
      });
    // TODO: chuyển sang trang Payments hoặc lưu receipts
    console.log("Phiếu thu đã sinh:", receipts);
    console.log((receipts));
    alert("Đã sinh phiếu thu cho tất cả hợp đồng đang hiệu lực!");
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Quản lý hợp đồng</h1>
          <p className="text-muted-foreground mt-2">
            Quản lý hợp đồng thuê phòng và điều khoản
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleAddContract} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Thêm hợp đồng
          </Button>
          <Button
            variant="secondary"
            className="flex items-center gap-2"
            onClick={() => {
              // Init usageInputs for all active contracts
              const activeContracts = contracts.filter(
                (c) => c.status === "active"
              );
              const initInputs: typeof usageInputs = {};
              activeContracts.forEach((c) => {
                initInputs[c.id] = {
                  electric: 0,
                  water: 0,
                  internet: 0,
                  service: 0,
                  other: c.otherFees || 0,
                  debt: 0,
                  tierElectric: false,
                  tierWater: false,
                };
              });
              setUsageInputs(initInputs);
              setIsReceiptDialogOpen(true);
            }}
          >
            <FileText className="h-4 w-4" />
            Sinh phiếu thu tất cả HĐ hiệu lực
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <FileText className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{contracts.length}</p>
                <p className="text-muted-foreground text-sm">Tổng hợp đồng</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {contracts.filter((c) => c.status === "active").length}
                </p>
                <p className="text-muted-foreground text-sm">Đang hiệu lực</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <Calendar className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {contracts.filter((c) => {
                    const daysRemaining = getContractDaysRemaining(c.endDate);
                    return daysRemaining <= 30 && daysRemaining > 0;
                  }).length}
                </p>
                <p className="text-muted-foreground text-sm">Sắp hết hạn</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {contracts.filter((c) => c.status === "expired").length}
                </p>
                <p className="text-muted-foreground text-sm">Đã hết hạn</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Danh sách hợp đồng</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Tìm kiếm hợp đồng..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Số HĐ</TableHead>
                  <TableHead>Khách hàng</TableHead>
                  <TableHead>Phòng</TableHead>
                  <TableHead>Thời hạn</TableHead>
                  <TableHead>Giá thuê</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead className="text-right">Thao tác</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContracts.map((contract) => {
                  const daysRemaining = getContractDaysRemaining(contract.endDate);
                  return (
                    <TableRow key={contract.id}>
                      <TableCell className="font-medium">
                        {contract.contractNumber}
                      </TableCell>
                      <TableCell>{contract.customerName}</TableCell>
                      <TableCell>{contract.roomNumber}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="text-sm">
                            {formatDate(contract.startDate)} -{" "}
                            {formatDate(contract.endDate)}
                          </div>
                          {daysRemaining > 0 && daysRemaining <= 30 && (
                            <div className="text-xs text-warning">
                              Còn {daysRemaining} ngày
                            </div>
                          )}
                          {daysRemaining <= 0 && (
                            <div className="text-xs text-destructive">
                              Đã hết hạn
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{formatCurrency(contract.rentPrice)}</TableCell>
                      <TableCell>{getStatusBadge(contract.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditContract(contract)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleCopyContract(contract)}
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteContract(contract.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Contract Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {editingContract ? "Chỉnh sửa hợp đồng" : "Thêm hợp đồng mới"}
            </DialogTitle>
          </DialogHeader>
          <ContractForm
            contract={editingContract}
            onSave={(contract) => {
              if (editingContract) {
                setContracts(
                  contracts.map((c) =>
                    c.id === editingContract.id ? contract : c
                  )
                );
              } else {
                setContracts([...contracts, { ...contract, id: Date.now().toString() }]);
              }
              setIsDialogOpen(false);
            }}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Receipt Dialog */}
      <Dialog open={isReceiptDialogOpen} onOpenChange={setIsReceiptDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Phiếu thu hợp đồng đang hiệu lực</DialogTitle>
          </DialogHeader>
          <div className="overflow-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Khách hàng</TableHead>
                  <TableHead>Phòng</TableHead>
                  <TableHead>Giá phòng</TableHead>
                  <TableHead>
                    Điện
                    <br />
                    <span className="text-xs">Số kWh</span>
                  </TableHead>
                  <TableHead>
                    Nước
                    <br />
                    <span className="text-xs">Số m³</span>
                  </TableHead>
                  <TableHead>Internet</TableHead>
                  <TableHead>Phí dịch vụ</TableHead>
                  <TableHead>Khác</TableHead>
                  <TableHead>Dư nợ</TableHead>
                  <TableHead>Tổng tiền</TableHead>
                  {/* <TableHead>QR Thanh toán</TableHead> */}
                </TableRow>
              </TableHeader>
              <TableBody>
                {contracts
                  .filter((c) => c.status === "active")
                  .map((contract) => {
                    const usage = usageInputs[contract.id] || {
                      electric: 0,
                      water: 0,
                      internet: 0,
                      service: 0,
                      other: contract.otherFees || 0,
                      debt: 0,
                      tierElectric: false,
                      tierWater: false,
                    };
                    const { room, electric, water, internet, service, other, debt, total } = calcTotal(contract, usage);
                    const qrData = JSON.stringify({
                      customer: contract.customerName,
                      contractNumber: contract.contractNumber,
                      amount: total,
                      room: contract.roomNumber,
                    });
                    return (
                      <TableRow key={contract.id}>
                        <TableCell>{contract.customerName}</TableCell>
                        <TableCell>{contract.roomNumber}</TableCell>
                        <TableCell>{formatCurrency(room)}</TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <Input
                              type="number"
                              min={0}
                              value={usage.electric}
                              onChange={(e) =>
                                setUsageInputs({
                                  ...usageInputs,
                                  [contract.id]: { ...usage, electric: Number(e.target.value) },
                                })
                              }
                              className="w-20"
                            />
                            <label className="flex items-center gap-1 text-xs">
                              <input
                                type="checkbox"
                                checked={usage.tierElectric}
                                onChange={(e) =>
                                  setUsageInputs({
                                    ...usageInputs,
                                    [contract.id]: { ...usage, tierElectric: e.target.checked },
                                  })
                                }
                              />
                              Tính theo bậc
                            </label>
                            <div className="text-xs text-muted-foreground">
                              {formatCurrency(electric)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            <Input
                              type="number"
                              min={0}
                              value={usage.water}
                              onChange={(e) =>
                                setUsageInputs({
                                  ...usageInputs,
                                  [contract.id]: { ...usage, water: Number(e.target.value) },
                                })
                              }
                              className="w-20"
                            />
                            <label className="flex items-center gap-1 text-xs">
                              <input
                                type="checkbox"
                                checked={usage.tierWater}
                                onChange={(e) =>
                                  setUsageInputs({
                                    ...usageInputs,
                                    [contract.id]: { ...usage, tierWater: e.target.checked },
                                  })
                                }
                              />
                              Tính theo bậc
                            </label>
                            <div className="text-xs text-muted-foreground">
                              {formatCurrency(water)}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min={0}
                            value={usage.internet}
                            onChange={(e) =>
                              setUsageInputs({
                                ...usageInputs,
                                [contract.id]: { ...usage, internet: Number(e.target.value) },
                              })
                            }
                            className="w-20"
                          />
                          <div className="text-xs text-muted-foreground">
                            {formatCurrency(internet)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min={0}
                            value={usage.service}
                            onChange={(e) =>
                              setUsageInputs({
                                ...usageInputs,
                                [contract.id]: { ...usage, service: Number(e.target.value) },
                              })
                            }
                            className="w-20"
                          />
                          <div className="text-xs text-muted-foreground">
                            {formatCurrency(service)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min={0}
                            value={usage.other}
                            onChange={(e) =>
                              setUsageInputs({
                                ...usageInputs,
                                [contract.id]: { ...usage, other: Number(e.target.value) },
                              })
                            }
                            className="w-20"
                          />
                          <div className="text-xs text-muted-foreground">
                            {formatCurrency(other)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min={0}
                            value={usage.debt}
                            onChange={(e) =>
                              setUsageInputs({
                                ...usageInputs,
                                [contract.id]: { ...usage, debt: Number(e.target.value) },
                              })
                            }
                            className="w-20"
                          />
                          <div className="text-xs text-muted-foreground">
                            {formatCurrency(debt)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="font-bold">{formatCurrency(total)}</span>
                        </TableCell>
                        {/* <TableCell>
                          <QRCode value={qrData} size={64} />
                          <div className="text-xs mt-1">{contract.customerName}</div>
                        </TableCell> */}
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </div>
          <div className="flex justify-end pt-4 gap-2">
            <Button
              variant="secondary"
              onClick={handleCreateReceipts}
            >
              Sinh phiếu thu
            </Button>
            <Button
              variant="outline"
              onClick={() => setIsReceiptDialogOpen(false)}
            >
              Đóng
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface ContractFormProps {
  contract?: Contract | null;
  onSave: (contract: Contract) => void;
  onCancel: () => void;
}

function ContractForm({ contract, onSave, onCancel }: ContractFormProps) {
  const [formData, setFormData] = useState<Partial<Contract>>({
    contractNumber: contract?.contractNumber || "",
    customerName: contract?.customerName || "",
    roomNumber: contract?.roomNumber || "",
    startDate: contract?.startDate || "",
    endDate: contract?.endDate || "",
    rentPrice: contract?.rentPrice || 0,
    depositAmount: contract?.depositAmount || 0,
    status: contract?.status || "pending",
    terms: contract?.terms || "",
    createdDate: contract?.createdDate || new Date().toISOString().split("T")[0],
    electricPrice: contract?.electricPrice || 4000,
    waterPrice: contract?.waterPrice || 25000,
    otherFees: contract?.otherFees || 0,
    customerId: contract?.customerId || "",
    roomId: contract?.roomId || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Contract);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="contractNumber">Số hợp đồng</Label>
          <Input
            id="contractNumber"
            value={formData.contractNumber}
            onChange={(e) =>
              setFormData({ ...formData, contractNumber: e.target.value })
            }
            placeholder="HD001"
            required
          />
        </div>
        <div>
          <Label htmlFor="status">Trạng thái</Label>
          <select
            id="status"
            value={formData.status}
            onChange={(e) =>
              setFormData({ ...formData, status: e.target.value as Contract["status"] })
            }
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
          >
            <option value="pending">Chờ ký</option>
            <option value="active">Đang hiệu lực</option>
            <option value="expired">Hết hạn</option>
            <option value="terminated">Đã chấm dứt</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="customerId">Khách hàng</Label>
          <select
            id="customerId"
            value={formData.customerId}
            onChange={(e) => {
              const customer = mockCustomers.find((c) => c.id === e.target.value);
              setFormData({
                ...formData,
                customerId: e.target.value,
                customerName: customer?.name || "",
              });
            }}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
            required
          >
            <option value="">Chọn khách hàng</option>
            {mockCustomers.map((customer) => (
              <option key={customer.id} value={customer.id}>
                {customer.name} - {customer.phone}
              </option>
            ))}
          </select>
        </div>
        <div>
          <Label htmlFor="roomId">Phòng thuê</Label>
          <select
            id="roomId"
            value={formData.roomId}
            onChange={(e) => {
              const room = mockRooms.find((r) => r.id === e.target.value);
              setFormData({
                ...formData,
                roomId: e.target.value,
                roomNumber: room?.number || "",
              });
            }}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
            required
          >
            <option value="">Chọn phòng</option>
            {mockRooms.map((room) => (
              <option key={room.id} value={room.id}>
                {room.number} - {room.type}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="startDate">Ngày bắt đầu</Label>
          <Input
            id="startDate"
            type="date"
            value={formData.startDate}
            onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
            required
          />
        </div>
        <div>
          <Label htmlFor="endDate">Ngày kết thúc</Label>
          <Input
            id="endDate"
            type="date"
            value={formData.endDate}
            onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="rentPrice">Giá thuê (VNĐ)</Label>
          <Input
            id="rentPrice"
            type="number"
            value={formData.rentPrice}
            onChange={(e) => setFormData({ ...formData, rentPrice: Number(e.target.value) })}
            placeholder="3500000"
          />
        </div>
        <div>
          <Label htmlFor="depositAmount">Tiền đặt cọc (VNĐ)</Label>
          <Input
            id="depositAmount"
            type="number"
            value={formData.depositAmount}
            onChange={(e) => setFormData({ ...formData, depositAmount: Number(e.target.value) })}
            placeholder="7000000"
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="electricPrice">Giá điện (VNĐ/kWh)</Label>
          <Input
            id="electricPrice"
            type="number"
            value={formData.electricPrice}
            onChange={(e) => setFormData({ ...formData, electricPrice: Number(e.target.value) })}
            placeholder="4000"
          />
        </div>
        <div>
          <Label htmlFor="waterPrice">Giá nước (VNĐ/m³)</Label>
          <Input
            id="waterPrice"
            type="number"
            value={formData.waterPrice}
            onChange={(e) => setFormData({ ...formData, waterPrice: Number(e.target.value) })}
            placeholder="25000"
          />
        </div>
        <div>
          <Label htmlFor="otherFees">Phí khác (VNĐ)</Label>
          <Input
            id="otherFees"
            type="number"
            value={formData.otherFees}
            onChange={(e) => setFormData({ ...formData, otherFees: Number(e.target.value) })}
            placeholder="100000"
          />
        </div>
      </div>

      <div>
        <Label htmlFor="terms">Điều khoản hợp đồng</Label>
        <Textarea
          id="terms"
          value={formData.terms}
          onChange={(e) => setFormData({ ...formData, terms: e.target.value })}
          placeholder="Nhập các điều khoản và quy định..."
          rows={3}
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Hủy
        </Button>
        <Button type="submit">
          {contract ? "Cập nhật" : "Thêm"}
        </Button>
      </div>
    </form>
  );
}