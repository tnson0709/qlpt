import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Plus, 
  Search, 
  Edit, 
  Copy, 
  Trash2,
  ArrowUpCircle,
  ArrowDownCircle,
  DollarSign,
  TrendingUp,
  TrendingDown
} from "lucide-react";

interface Payment {
  id: string;
  type: "income" | "expense";
  category: string;
  amount: number;
  description: string;
  date: string;
  customerName?: string;
  roomNumber?: string;
  paymentMethod: "cash" | "transfer" | "card";
  status: "completed" | "pending" | "cancelled";
  receiptNumber?: string;
}

const mockPayments: Payment[] = [
  {
    id: "1",
    type: "income",
    category: "Tiền thuê phòng",
    amount: 3500000,
    description: "Tiền thuê phòng P101 tháng 8/2024",
    date: "2024-08-05",
    customerName: "Nguyễn Văn A",
    roomNumber: "P101",
    paymentMethod: "transfer",
    status: "completed",
    receiptNumber: "PT001"
  },
  {
    id: "2",
    type: "income",
    category: "Tiền điện nước",
    amount: 450000,
    description: "Tiền điện nước P101 tháng 7/2024",
    date: "2024-08-03",
    customerName: "Nguyễn Văn A",
    roomNumber: "P101",
    paymentMethod: "cash",
    status: "completed",
    receiptNumber: "PT002"
  },
  {
    id: "3",
    type: "expense",
    category: "Sửa chữa",
    amount: 500000,
    description: "Sửa chữa điều hòa phòng P202",
    date: "2024-08-01",
    roomNumber: "P202",
    paymentMethod: "cash",
    status: "completed",
    receiptNumber: "PC001"
  },
  {
    id: "4",
    type: "income",
    category: "Tiền thuê phòng",
    amount: 4000000,
    description: "Tiền thuê phòng P201 tháng 8/2024",
    date: "2024-08-01",
    customerName: "Trần Thị B",
    roomNumber: "P201",
    paymentMethod: "transfer",
    status: "completed",
    receiptNumber: "PT003"
  },
  {
    id: "5",
    type: "expense",
    category: "Vật tư",
    amount: 200000,
    description: "Mua bóng đèn, ổ cắm",
    date: "2024-07-28",
    paymentMethod: "cash",
    status: "completed",
    receiptNumber: "PC002"
  }
];

export default function Payments() {
  const [payments, setPayments] = useState<Payment[]>(mockPayments);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<"all" | "income" | "expense">("all");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);

  const filteredPayments = payments.filter(payment => {
    const matchesSearch = 
      payment.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.roomNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === "all" || payment.type === filterType;
    
    return matchesSearch && matchesType;
  });

  const totalIncome = payments
    .filter(p => p.type === "income" && p.status === "completed")
    .reduce((sum, p) => sum + p.amount, 0);

  const totalExpense = payments
    .filter(p => p.type === "expense" && p.status === "completed")
    .reduce((sum, p) => sum + p.amount, 0);

  const netProfit = totalIncome - totalExpense;

  const getStatusBadge = (status: Payment["status"]) => {
    switch (status) {
      case "completed":
        return <Badge variant="secondary">Hoàn thành</Badge>;
      case "pending":
        return <Badge className="bg-warning text-warning-foreground">Chờ xử lý</Badge>;
      case "cancelled":
        return <Badge variant="destructive">Đã hủy</Badge>;
    }
  };

  const getPaymentMethodBadge = (method: Payment["paymentMethod"]) => {
    switch (method) {
      case "cash":
        return <Badge variant="outline">Tiền mặt</Badge>;
      case "transfer":
        return <Badge variant="outline">Chuyển khoản</Badge>;
      case "card":
        return <Badge variant="outline">Thẻ</Badge>;
    }
  };

  const handleAddPayment = () => {
    setEditingPayment(null);
    setIsDialogOpen(true);
  };

  const handleEditPayment = (payment: Payment) => {
    setEditingPayment(payment);
    setIsDialogOpen(true);
  };

  const handleCopyPayment = (payment: Payment) => {
    const newPayment = {
      ...payment,
      id: Date.now().toString(),
      receiptNumber: undefined,
      status: "pending" as const,
      date: new Date().toISOString().split('T')[0]
    };
    setPayments([...payments, newPayment]);
  };

  const handleDeletePayment = (paymentId: string) => {
    setPayments(payments.filter(payment => payment.id !== paymentId));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('vi-VN');
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Quản lý thu chi</h1>
          <p className="text-muted-foreground mt-2">
            Quản lý các khoản thu và chi của hệ thống
          </p>
        </div>
        <Button onClick={handleAddPayment} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Thêm giao dịch
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <ArrowUpCircle className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-success">{formatCurrency(totalIncome)}</p>
                <p className="text-muted-foreground text-sm">Tổng thu</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                <ArrowDownCircle className="h-6 w-6 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold text-destructive">{formatCurrency(totalExpense)}</p>
                <p className="text-muted-foreground text-sm">Tổng chi</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                netProfit >= 0 ? 'bg-success/10' : 'bg-destructive/10'
              }`}>
                {netProfit >= 0 ? (
                  <TrendingUp className="h-6 w-6 text-success" />
                ) : (
                  <TrendingDown className="h-6 w-6 text-destructive" />
                )}
              </div>
              <div>
                <p className={`text-2xl font-bold ${netProfit >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {formatCurrency(netProfit)}
                </p>
                <p className="text-muted-foreground text-sm">Lợi nhuận</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{payments.length}</p>
                <p className="text-muted-foreground text-sm">Tổng giao dịch</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Danh sách giao dịch</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-center gap-4 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Tìm kiếm giao dịch..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as typeof filterType)}
              className="h-10 px-3 rounded-md border border-input bg-background"
            >
              <option value="all">Tất cả</option>
              <option value="income">Khoản thu</option>
              <option value="expense">Khoản chi</option>
            </select>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ngày</TableHead>
                  <TableHead>Loại</TableHead>
                  <TableHead>Danh mục</TableHead>
                  <TableHead>Mô tả</TableHead>
                  <TableHead>Số tiền</TableHead>
                  <TableHead>Phương thức</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead className="text-right">Thao tác</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPayments.map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell>{formatDate(payment.date)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {payment.type === "income" ? (
                          <ArrowUpCircle className="h-4 w-4 text-success" />
                        ) : (
                          <ArrowDownCircle className="h-4 w-4 text-destructive" />
                        )}
                        {payment.type === "income" ? "Thu" : "Chi"}
                      </div>
                    </TableCell>
                    <TableCell>{payment.category}</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{payment.description}</p>
                        {payment.customerName && (
                          <p className="text-sm text-muted-foreground">
                            {payment.customerName} - {payment.roomNumber}
                          </p>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className={payment.type === "income" ? "text-success" : "text-destructive"}>
                        {payment.type === "income" ? "+" : "-"}{formatCurrency(payment.amount)}
                      </span>
                    </TableCell>
                    <TableCell>{getPaymentMethodBadge(payment.paymentMethod)}</TableCell>
                    <TableCell>{getStatusBadge(payment.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditPayment(payment)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyPayment(payment)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeletePayment(payment.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Payment Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingPayment ? "Chỉnh sửa giao dịch" : "Thêm giao dịch mới"}
            </DialogTitle>
          </DialogHeader>
          <PaymentForm 
            payment={editingPayment} 
            onSave={(payment) => {
              if (editingPayment) {
                setPayments(payments.map(p => p.id === editingPayment.id ? payment : p));
              } else {
                setPayments([...payments, { ...payment, id: Date.now().toString() }]);
              }
              setIsDialogOpen(false);
            }}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface PaymentFormProps {
  payment?: Payment | null;
  onSave: (payment: Payment) => void;
  onCancel: () => void;
}

function PaymentForm({ payment, onSave, onCancel }: PaymentFormProps) {
  const [formData, setFormData] = useState<Partial<Payment>>({
    type: payment?.type || "income",
    category: payment?.category || "",
    amount: payment?.amount || 0,
    description: payment?.description || "",
    date: payment?.date || new Date().toISOString().split('T')[0],
    customerName: payment?.customerName || "",
    roomNumber: payment?.roomNumber || "",
    paymentMethod: payment?.paymentMethod || "cash",
    status: payment?.status || "completed",
    receiptNumber: payment?.receiptNumber || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Payment);
  };

  const incomeCategories = [
    "Tiền thuê phòng",
    "Tiền điện nước",
    "Tiền đặt cọc",
    "Phí dịch vụ",
    "Khác"
  ];

  const expenseCategories = [
    "Sửa chữa",
    "Vật tư",
    "Điện nước chung",
    "Vệ sinh",
    "Bảo trì",
    "Khác"
  ];

  const categories = formData.type === "income" ? incomeCategories : expenseCategories;

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="type">Loại giao dịch</Label>
          <select
            id="type"
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value as Payment["type"], category: "" })}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
          >
            <option value="income">Khoản thu</option>
            <option value="expense">Khoản chi</option>
          </select>
        </div>
        <div>
          <Label htmlFor="category">Danh mục</Label>
          <select
            id="category"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
            required
          >
            <option value="">Chọn danh mục</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="amount">Số tiền (VNĐ)</Label>
          <Input
            id="amount"
            type="number"
            value={formData.amount}
            onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
            placeholder="1000000"
            required
          />
        </div>
        <div>
          <Label htmlFor="date">Ngày giao dịch</Label>
          <Input
            id="date"
            type="date"
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="description">Mô tả</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Mô tả chi tiết về giao dịch..."
          rows={2}
          required
        />
      </div>

      {formData.type === "income" && (
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="customerName">Tên khách hàng</Label>
            <Input
              id="customerName"
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              placeholder="Nguyễn Văn A"
            />
          </div>
          <div>
            <Label htmlFor="roomNumber">Số phòng</Label>
            <Input
              id="roomNumber"
              value={formData.roomNumber}
              onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
              placeholder="P101"
            />
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="paymentMethod">Phương thức</Label>
          <select
            id="paymentMethod"
            value={formData.paymentMethod}
            onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value as Payment["paymentMethod"] })}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
          >
            <option value="cash">Tiền mặt</option>
            <option value="transfer">Chuyển khoản</option>
            <option value="card">Thẻ</option>
          </select>
        </div>
        <div>
          <Label htmlFor="status">Trạng thái</Label>
          <select
            id="status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as Payment["status"] })}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
          >
            <option value="completed">Hoàn thành</option>
            <option value="pending">Chờ xử lý</option>
            <option value="cancelled">Đã hủy</option>
          </select>
        </div>
      </div>

      <div>
        <Label htmlFor="receiptNumber">Số phiếu thu/chi</Label>
        <Input
          id="receiptNumber"
          value={formData.receiptNumber}
          onChange={(e) => setFormData({ ...formData, receiptNumber: e.target.value })}
          placeholder="PT001 hoặc PC001"
        />
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Hủy
        </Button>
        <Button type="submit">
          {payment ? "Cập nhật" : "Thêm"}
        </Button>
      </div>
    </form>
  );
}