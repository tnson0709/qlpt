import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Plus, 
  Search, 
  Edit, 
  Copy, 
  Trash2,
  Building2,
  Users,
  DollarSign
} from "lucide-react";

import { db } from "@/lib/db";
import { exportToXlsx, importFromXlsx } from "@/lib/excel";
import { toast } from "@/hooks/use-toast";

interface Room {
  id: string;
  number: string;
  name: string;
  address: string;
  rentPrice: number;
  electricPrice: number;
  waterPrice: number;
  otherFees: number;
  status: "occupied" | "vacant" | "maintenance";
  customer?: string;
}

const mockRooms: Room[] = [
  {
    id: "1",
    number: "P101",
    name: "Phòng 101 - Tầng 1",
    address: "123 Đường ABC, Quận 1",
    rentPrice: 3500000,
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 100000,
    status: "occupied",
    customer: "Nguyễn Văn A"
  },
  {
    id: "2", 
    number: "P102",
    name: "Phòng 102 - Tầng 1",
    address: "123 Đường ABC, Quận 1",
    rentPrice: 3500000,
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 100000,
    status: "vacant"
  },
  {
    id: "3",
    number: "P201",
    name: "Phòng 201 - Tầng 2",
    address: "123 Đường ABC, Quận 1", 
    rentPrice: 4000000,
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 150000,
    status: "occupied",
    customer: "Trần Thị B"
  },
  {
    id: "4",
    number: "P202",
    name: "Phòng 202 - Tầng 2",
    address: "123 Đường ABC, Quận 1",
    rentPrice: 4000000,
    electricPrice: 4000,
    waterPrice: 25000,
    otherFees: 150000,
    status: "maintenance"
  }
];

export default function Rooms() {
  const [rooms, setRooms] = useState<Room[]>(mockRooms);
  const [searchTerm, setSearchTerm] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    db.rooms.toArray().then(async (rows) => {
      if (rows.length > 0) {
        setRooms(rows as Room[]);
      } else {
        await db.rooms.bulkAdd(mockRooms as Room[]);
        setRooms(mockRooms);
      }
    }).catch(console.error);
  }, []);

  const handleExport = () => {
    exportToXlsx({ filename: 'rooms.xlsx', data: rooms });
  };

  const handleImport = async (file: File) => {
    try {
      const rows = await importFromXlsx(file);
      const mapped: Room[] = rows.map((r: any, idx: number) => ({
        id: String(r.id || `${Date.now()}_${idx}`),
        number: String(r.number || ''),
        name: String(r.name || ''),
        address: String(r.address || ''),
        rentPrice: Number(r.rentPrice || 0),
        electricPrice: Number(r.electricPrice || 0),
        waterPrice: Number(r.waterPrice || 0),
        otherFees: Number(r.otherFees || 0),
        status: (r.status as Room["status"]) || 'vacant',
        customer: r.customer ? String(r.customer) : undefined,
      }));
      await db.rooms.clear();
      if (mapped.length) await db.rooms.bulkAdd(mapped);
      setRooms(mapped);
      toast({ title: 'Nhập Excel thành công', description: `Đã nhập ${mapped.length} phòng` });
    } catch (e) {
      toast({ title: 'Nhập Excel thất bại', description: 'Vui lòng kiểm tra file', variant: 'destructive' as any });
    }
  };

  const filteredRooms = rooms.filter(room =>
    room.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    room.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    room.customer?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: Room["status"]) => {
    switch (status) {
      case "occupied":
        return <Badge variant="secondary">Đã thuê</Badge>;
      case "vacant":
        return <Badge variant="outline">Trống</Badge>;
      case "maintenance":
        return <Badge variant="destructive">Bảo trì</Badge>;
    }
  };

  const handleAddRoom = () => {
    setEditingRoom(null);
    setIsDialogOpen(true);
  };

  const handleEditRoom = (room: Room) => {
    setEditingRoom(room);
    setIsDialogOpen(true);
  };

  const handleCopyRoom = async (room: Room) => {
    const newRoom: Room = {
      ...room,
      id: Date.now().toString(),
      number: `${room.number}_Copy`,
      name: `${room.name} (Copy)`,
      status: "vacant",
      customer: undefined,
    };
    await db.rooms.add(newRoom);
    setRooms([...rooms, newRoom]);
    toast({ title: 'Đã nhân bản phòng', description: newRoom.number });
  };

  const handleDeleteRoom = async (roomId: string) => {
    await db.rooms.delete(roomId);
    setRooms(rooms.filter(room => room.id !== roomId));
    toast({ title: 'Đã xóa phòng' });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(amount);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Quản lý phòng</h1>
          <p className="text-muted-foreground mt-2">
            Quản lý thông tin phòng thuê và giá cả
          </p>
        </div>
        <div className="flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleImport(f);
              if (fileInputRef.current) fileInputRef.current.value = '';
            }}
          />
          <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
            Nhập Excel
          </Button>
          <Button variant="outline" onClick={handleExport}>
            Xuất Excel
          </Button>
          <Button onClick={handleAddRoom} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Thêm phòng
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{rooms.length}</p>
                <p className="text-muted-foreground text-sm">Tổng số phòng</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {rooms.filter(r => r.status === "occupied").length}
                </p>
                <p className="text-muted-foreground text-sm">Đã thuê</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {formatCurrency(
                    rooms
                      .filter(r => r.status === "occupied")
                      .reduce((sum, r) => sum + r.rentPrice, 0)
                  )}
                </p>
                <p className="text-muted-foreground text-sm">Doanh thu/tháng</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Danh sách phòng</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Tìm kiếm phòng..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Số phòng</TableHead>
                  <TableHead>Tên phòng</TableHead>
                  <TableHead>Khách thuê</TableHead>
                  <TableHead>Giá thuê</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead className="text-right">Thao tác</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRooms.map((room) => (
                  <TableRow key={room.id}>
                    <TableCell className="font-medium">{room.number}</TableCell>
                    <TableCell>{room.name}</TableCell>
                    <TableCell>{room.customer || "-"}</TableCell>
                    <TableCell>{formatCurrency(room.rentPrice)}</TableCell>
                    <TableCell>{getStatusBadge(room.status)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditRoom(room)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyRoom(room)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteRoom(room.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Room Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingRoom ? "Chỉnh sửa phòng" : "Thêm phòng mới"}
            </DialogTitle>
          </DialogHeader>
          <RoomForm 
            room={editingRoom} 
            onSave={async (room) => {
              if (editingRoom) {
                await db.rooms.put({ ...room, id: editingRoom.id });
                setRooms(rooms.map(r => r.id === editingRoom.id ? { ...room, id: editingRoom.id } : r));
                toast({ title: 'Đã cập nhật phòng', description: room.number });
              } else {
                const newRoom = { ...room, id: Date.now().toString() };
                await db.rooms.add(newRoom);
                setRooms([...rooms, newRoom]);
                toast({ title: 'Đã thêm phòng', description: newRoom.number });
              }
              setIsDialogOpen(false);
            }}
            onCancel={() => setIsDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface RoomFormProps {
  room?: Room | null;
  onSave: (room: Room) => void;
  onCancel: () => void;
}

function RoomForm({ room, onSave, onCancel }: RoomFormProps) {
  const [formData, setFormData] = useState<Partial<Room>>({
    number: room?.number || "",
    name: room?.name || "",
    address: room?.address || "",
    rentPrice: room?.rentPrice || 0,
    electricPrice: room?.electricPrice || 4000,
    waterPrice: room?.waterPrice || 25000,
    otherFees: room?.otherFees || 0,
    status: room?.status || "vacant",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData as Room);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="number">Số phòng</Label>
          <Input
            id="number"
            value={formData.number}
            onChange={(e) => setFormData({ ...formData, number: e.target.value })}
            placeholder="P101"
            required
          />
        </div>
        <div>
          <Label htmlFor="status">Trạng thái</Label>
          <select
            id="status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value as Room["status"] })}
            className="w-full h-10 px-3 rounded-md border border-input bg-background"
          >
            <option value="vacant">Trống</option>
            <option value="occupied">Đã thuê</option>
            <option value="maintenance">Bảo trì</option>
          </select>
        </div>
      </div>

      <div>
        <Label htmlFor="name">Tên phòng</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Phòng 101 - Tầng 1"
          required
        />
      </div>

      <div>
        <Label htmlFor="address">Địa chỉ</Label>
        <Textarea
          id="address"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="123 Đường ABC, Quận 1"
          rows={2}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="rentPrice">Giá thuê (VNĐ)</Label>
          <Input
            id="rentPrice"
            type="number"
            value={formData.rentPrice}
            onChange={(e) => setFormData({ ...formData, rentPrice: Number(e.target.value) })}
            placeholder="3500000"
          />
        </div>
        <div>
          <Label htmlFor="electricPrice">Giá điện (VNĐ/kWh)</Label>
          <Input
            id="electricPrice"
            type="number"
            value={formData.electricPrice}
            onChange={(e) => setFormData({ ...formData, electricPrice: Number(e.target.value) })}
            placeholder="4000"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="waterPrice">Giá nước (VNĐ/m³)</Label>
          <Input
            id="waterPrice"
            type="number"
            value={formData.waterPrice}
            onChange={(e) => setFormData({ ...formData, waterPrice: Number(e.target.value) })}
            placeholder="25000"
          />
        </div>
        <div>
          <Label htmlFor="otherFees">Phí khác (VNĐ)</Label>
          <Input
            id="otherFees"
            type="number"
            value={formData.otherFees}
            onChange={(e) => setFormData({ ...formData, otherFees: Number(e.target.value) })}
            placeholder="100000"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Hủy
        </Button>
        <Button type="submit">
          {room ? "Cập nhật" : "Thêm"}
        </Button>
      </div>
    </form>
  );
}