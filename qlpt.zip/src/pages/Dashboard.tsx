import { StatsCard } from "@/components/dashboard/StatsCard";
import { RevenueChart } from "@/components/dashboard/RevenueChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Building2, 
  Users, 
  DollarSign, 
  TrendingUp,
  Calendar,
  AlertTriangle
} from "lucide-react";

export default function Dashboard() {
  const upcomingExpiries = [
    { id: 1, customer: "Nguyễn Văn A", room: "P101", daysLeft: 3, status: "critical" },
    { id: 2, customer: "Trần Thị B", room: "P205", daysLeft: 7, status: "warning" },
    { id: 3, customer: "Lê Văn C", room: "P303", daysLeft: 14, status: "info" },
    { id: 4, customer: "Phạm Thị D", room: "P408", daysLeft: 1, status: "critical" },
  ];

  return (
    <div className="space-y-8 p-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Tổng quan hệ thống quản lý phòng trọ
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Tổng số phòng"
          value="48"
          change="+2 phòng mới"
          changeType="positive"
          icon={Building2}
        />
        <StatsCard
          title="Khách hàng hiện tại"
          value="42"
          change="87.5% lấp đầy"
          changeType="positive"
          icon={Users}
        />
        <StatsCard
          title="Doanh thu tháng này"
          value="68.5M"
          change="+12.5% so với tháng trước"
          changeType="positive"
          icon={DollarSign}
        />
        <StatsCard
          title="Lợi nhuận"
          value="48.2M"
          change="+8.2% so với tháng trước"
          changeType="positive"
          icon={TrendingUp}
        />
      </div>

      {/* Charts and Tables */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Revenue Chart */}
        <div className="md:col-span-2">
          <RevenueChart />
        </div>

        {/* Upcoming Expiries */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Hợp đồng sắp hết hạn
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingExpiries.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-current opacity-60" />
                    <div>
                      <p className="font-medium text-sm">{item.customer}</p>
                      <p className="text-muted-foreground text-xs">{item.room}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge 
                      variant={
                        item.status === "critical" ? "destructive" : 
                        item.status === "warning" ? "secondary" : "outline"
                      }
                      className="text-xs"
                    >
                      {item.daysLeft} ngày
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Cần chú ý
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-lg bg-destructive/10">
                <div>
                  <p className="font-medium text-sm">Tiền điện chưa thu</p>
                  <p className="text-muted-foreground text-xs">6 phòng</p>
                </div>
                <Badge variant="destructive">6.2M</Badge>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-warning/10">
                <div>
                  <p className="font-medium text-sm">Báo cáo bảo trì</p>
                  <p className="text-muted-foreground text-xs">3 phòng</p>
                </div>
                <Badge variant="secondary">Cần xử lý</Badge>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-success/10">
                <div>
                  <p className="font-medium text-sm">Phòng trống</p>
                  <p className="text-muted-foreground text-xs">6 phòng</p>
                </div>
                <Badge variant="outline">Sẵn sàng</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}