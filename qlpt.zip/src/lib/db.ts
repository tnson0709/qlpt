import Dexie, { Table } from 'dexie';

export type RoomStatus = 'occupied' | 'vacant' | 'maintenance';
export interface Room {
  id: string;
  number: string;
  name: string;
  address: string;
  rentPrice: number;
  electricPrice: number;
  waterPrice: number;
  otherFees: number;
  status: RoomStatus;
  customer?: string;
}

export type CustomerStatus = 'active' | 'inactive' | 'pending';
export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  idNumber: string;
  address: string;
  roomNumber?: string;
  status: CustomerStatus;
  depositAmount: number;
  startDate?: string;
  endDate?: string;
}

export type ContractStatus = 'active' | 'expired' | 'terminated' | 'pending';
export interface Contract {
  id: string;
  contractNumber: string;
  customerName: string;
  roomNumber: string;
  startDate: string;
  endDate: string;
  rentPrice: number;
  depositAmount: number;
  status: ContractStatus;
  terms: string;
  createdDate: string;
  electricPrice: number;
  waterPrice: number;
  otherFees: number;
  customerId: string;
  roomId: string;
}

export type PaymentType = 'income' | 'expense';
export type PaymentMethod = 'cash' | 'transfer' | 'card';
export type PaymentStatus = 'completed' | 'pending' | 'cancelled';
export interface Payment {
  id: string;
  type: PaymentType;
  category: string;
  amount: number;
  description: string;
  date: string; // ISO date
  customerName?: string;
  roomNumber?: string;
  paymentMethod: PaymentMethod;
  status: PaymentStatus;
  receiptNumber?: string;
}

export interface MeterReading {
  id: string;
  contractId: string;
  contractNumber: string;
  customerName: string;
  roomNumber: string;
  month: number; // 1-12
  year: number;
  electricStart: number;
  electricEnd: number;
  waterStart: number;
  waterEnd: number;
  electricPrice: number; // from contract
  waterPrice: number; // from contract
  rentPrice: number; // from contract
  otherFees: number; // from contract or override
  totalElectricKwh: number;
  totalWaterM3: number;
  computedElectricAmount: number;
  computedWaterAmount: number;
  totalAmount: number; // rent + electric + water + other
  createdAt: string; // ISO
}

class AppDB extends Dexie {
  rooms!: Table<Room, string>;
  customers!: Table<Customer, string>;
  contracts!: Table<Contract, string>;
  payments!: Table<Payment, string>;
  meterReadings!: Table<MeterReading, string>;

  constructor() {
    super('rental_manager_db');
    this.version(1).stores({
      rooms: 'id, number, status',
      customers: 'id, name, phone, status',
      contracts: 'id, contractNumber, customerId, roomId, status',
      payments: 'id, type, date, status',
      meterReadings: 'id, contractId, year, month',
    });
  }
}

export const db = new AppDB();

// Seed initial data if empty (idempotent)
async function seedIfEmpty() {
  const [roomsCount, customersCount, contractsCount, paymentsCount] = await Promise.all([
    db.rooms.count(),
    db.customers.count(),
    db.contracts.count(),
    db.payments.count(),
  ]);

  if (roomsCount === 0) {
    const initialRooms: Room[] = [
      {
        id: '1',
        number: 'P101',
        name: 'Phòng 101 - Tầng 1',
        address: '123 Đường ABC, Quận 1',
        rentPrice: 3500000,
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 100000,
        status: 'occupied',
        customer: 'Nguyễn Văn A',
      },
      {
        id: '2',
        number: 'P102',
        name: 'Phòng 102 - Tầng 1',
        address: '123 Đường ABC, Quận 1',
        rentPrice: 3500000,
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 100000,
        status: 'vacant',
      },
      {
        id: '3',
        number: 'P201',
        name: 'Phòng 201 - Tầng 2',
        address: '123 Đường ABC, Quận 1',
        rentPrice: 4000000,
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 150000,
        status: 'occupied',
        customer: 'Trần Thị B',
      },
      {
        id: '4',
        number: 'P202',
        name: 'Phòng 202 - Tầng 2',
        address: '123 Đường ABC, Quận 1',
        rentPrice: 4000000,
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 150000,
        status: 'maintenance',
      },
    ];
    await db.rooms.bulkAdd(initialRooms);
  }

  if (customersCount === 0) {
    const initialCustomers: Customer[] = [
      {
        id: '1',
        name: 'Nguyễn Văn A',
        phone: '0123456789',
        email: 'nguyenvana@email.com',
        idNumber: '123456789',
        address: '456 Đường XYZ, Quận 2',
        roomNumber: 'P101',
        status: 'active',
        depositAmount: 7000000,
        startDate: '2024-01-01',
        endDate: '2024-12-31',
      },
      {
        id: '2',
        name: 'Trần Thị B',
        phone: '0987654321',
        email: 'tranthib@email.com',
        idNumber: '987654321',
        address: '789 Đường DEF, Quận 3',
        roomNumber: 'P201',
        status: 'active',
        depositAmount: 8000000,
        startDate: '2024-02-01',
        endDate: '2024-12-31',
      },
      {
        id: '3',
        name: 'Lê Văn C',
        phone: '0345678901',
        email: 'levanc@email.com',
        idNumber: '345678901',
        address: '321 Đường GHI, Quận 4',
        status: 'pending',
        depositAmount: 3500000,
      },
    ];
    await db.customers.bulkAdd(initialCustomers);
  }

  if (contractsCount === 0) {
    const initialContracts: Contract[] = [
      {
        id: '1',
        contractNumber: 'HD001',
        customerName: 'Nguyễn Văn A',
        roomNumber: 'P101',
        startDate: '2024-01-01',
        endDate: '2024-12-31',
        rentPrice: 3500000,
        depositAmount: 7000000,
        status: 'active',
        terms: 'Thanh toán tiền thuê vào ngày 5 hàng tháng. Không được nuôi thú cưng.',
        createdDate: '2023-12-15',
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 100000,
        customerId: '1',
        roomId: '1',
      },
      {
        id: '2',
        contractNumber: 'HD002',
        customerName: 'Trần Thị B',
        roomNumber: 'P201',
        startDate: '2024-02-01',
        endDate: '2024-12-31',
        rentPrice: 4000000,
        depositAmount: 8000000,
        status: 'active',
        terms: 'Thanh toán tiền thuê vào ngày 1 hàng tháng. Được phép nấu ăn.',
        createdDate: '2024-01-20',
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 150000,
        customerId: '2',
        roomId: '2',
      },
      {
        id: '3',
        contractNumber: 'HD003',
        customerName: 'Lê Văn C',
        roomNumber: 'P102',
        startDate: '2023-06-01',
        endDate: '2024-05-31',
        rentPrice: 3500000,
        depositAmount: 7000000,
        status: 'expired',
        terms: 'Hợp đồng 12 tháng. Không hút thuốc trong phòng.',
        createdDate: '2023-05-15',
        electricPrice: 4000,
        waterPrice: 25000,
        otherFees: 100000,
        customerId: '3',
        roomId: '3',
      },
    ];
    await db.contracts.bulkAdd(initialContracts);
  }

  if (paymentsCount === 0) {
    const initialPayments: Payment[] = [
      {
        id: '1',
        type: 'income',
        category: 'Tiền thuê phòng',
        amount: 3500000,
        description: 'Tiền thuê phòng P101 tháng 8/2024',
        date: '2024-08-05',
        customerName: 'Nguyễn Văn A',
        roomNumber: 'P101',
        paymentMethod: 'transfer',
        status: 'completed',
        receiptNumber: 'PT001',
      },
      {
        id: '2',
        type: 'income',
        category: 'Tiền điện nước',
        amount: 450000,
        description: 'Tiền điện nước P101 tháng 7/2024',
        date: '2024-08-03',
        customerName: 'Nguyễn Văn A',
        roomNumber: 'P101',
        paymentMethod: 'cash',
        status: 'completed',
        receiptNumber: 'PT002',
      },
      {
        id: '3',
        type: 'expense',
        category: 'Sửa chữa',
        amount: 500000,
        description: 'Sửa chữa điều hòa phòng P202',
        date: '2024-08-01',
        roomNumber: 'P202',
        paymentMethod: 'cash',
        status: 'completed',
        receiptNumber: 'PC001',
      },
      {
        id: '4',
        type: 'income',
        category: 'Tiền thuê phòng',
        amount: 4000000,
        description: 'Tiền thuê phòng P201 tháng 8/2024',
        date: '2024-08-01',
        customerName: 'Trần Thị B',
        roomNumber: 'P201',
        paymentMethod: 'transfer',
        status: 'completed',
        receiptNumber: 'PT003',
      },
      {
        id: '5',
        type: 'expense',
        category: 'Vật tư',
        amount: 200000,
        description: 'Mua bóng đèn, ổ cắm',
        date: '2024-07-28',
        paymentMethod: 'cash',
        status: 'completed',
        receiptNumber: 'PC002',
      },
    ];
    await db.payments.bulkAdd(initialPayments);
  }
}

// Kick off seed lazily when module is loaded
seedIfEmpty().catch(console.error);

// Helpers for bills calculation
export function calcMonthlyBill(params: {
  rentPrice: number;
  electricStart: number;
  electricEnd: number;
  electricPrice: number;
  waterStart: number;
  waterEnd: number;
  waterPrice: number;
  otherFees?: number;
}) {
  const totalElectricKwh = Math.max(0, (params.electricEnd ?? 0) - (params.electricStart ?? 0));
  const totalWaterM3 = Math.max(0, (params.waterEnd ?? 0) - (params.waterStart ?? 0));
  const computedElectricAmount = totalElectricKwh * (params.electricPrice ?? 0);
  const computedWaterAmount = totalWaterM3 * (params.waterPrice ?? 0);
  const totalAmount = (params.rentPrice ?? 0) + computedElectricAmount + computedWaterAmount + (params.otherFees ?? 0);
  return {
    totalElectricKwh,
    totalWaterM3,
    computedElectricAmount,
    computedWaterAmount,
    totalAmount,
  };
}
