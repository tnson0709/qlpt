import * as XLSX from 'xlsx';

export function exportToXlsx<T extends Record<string, any>>(opts: {
  filename: string;
  sheetName?: string;
  data: T[];
}) {
  const { filename, sheetName = 'Data', data } = opts;
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, ensureXlsx(filename));
}

export async function importFromXlsx(file: File): Promise<Record<string, any>[]> {
  const data = await file.arrayBuffer();
  const wb = XLSX.read(data);
  const firstSheet = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(firstSheet, { defval: '' });
}

function ensureXlsx(name: string) {
  return name.endsWith('.xlsx') ? name : `${name}.xlsx`;
}
