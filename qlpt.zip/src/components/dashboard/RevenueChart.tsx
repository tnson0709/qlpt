import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip 
} from "recharts";

const data = [
  { month: "T1", revenue: 45000000, expenses: 12000000 },
  { month: "T2", revenue: 52000000, expenses: 15000000 },
  { month: "T3", revenue: 48000000, expenses: 13000000 },
  { month: "T4", revenue: 61000000, expenses: 18000000 },
  { month: "T5", revenue: 55000000, expenses: 16000000 },
  { month: "T6", revenue: 67000000, expenses: 19000000 },
  { month: "T7", revenue: 59000000, expenses: 17000000 },
  { month: "T8", revenue: 72000000, expenses: 21000000 },
  { month: "T9", revenue: 68000000, expenses: 20000000 },
  { month: "T10", revenue: 75000000, expenses: 22000000 },
  { month: "T11", revenue: 71000000, expenses: 20000000 },
  { month: "T12", revenue: 78000000, expenses: 24000000 },
];

export function RevenueChart() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Doanh thu & Chi phí theo tháng</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="revenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0.1}/>
              </linearGradient>
              <linearGradient id="expenses" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis 
              dataKey="month" 
              className="text-muted-foreground"
              fontSize={12}
            />
            <YAxis 
              className="text-muted-foreground"
              fontSize={12}
              tickFormatter={(value) => `${(value / 1000000).toFixed(0)}M`}
            />
            <Tooltip 
              formatter={(value: number, name: string) => [
                `${(value / 1000000).toFixed(1)}M VNĐ`, 
                name === 'revenue' ? 'Doanh thu' : 'Chi phí'
              ]}
              labelFormatter={(label) => `Tháng ${label}`}
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
              }}
            />
            <Area 
              type="monotone" 
              dataKey="revenue" 
              stroke="hsl(var(--primary))" 
              fillOpacity={1} 
              fill="url(#revenue)" 
              strokeWidth={2}
            />
            <Area 
              type="monotone" 
              dataKey="expenses" 
              stroke="hsl(var(--destructive))" 
              fillOpacity={1} 
              fill="url(#expenses)" 
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}