-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th8 12, 2025 lúc 09:38 PM
-- Phiên bản máy phục vụ: 10.11.13-MariaDB-cll-lve
-- Phiên bản PHP: 8.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `bsgsfviz_seven_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `userID` int(11) NOT NULL,
  `firstname` varchar(200) DEFAULT NULL COMMENT 'Họ và đệm',
  `lastname` varchar(100) NOT NULL DEFAULT 'Khách',
  `fullname` varchar(200) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `IP` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 0 COMMENT '0: khách; 1 active; 2 deactive; 3 khác',
  `registered` datetime DEFAULT NULL,
  `createdate` datetime NOT NULL DEFAULT current_timestamp(),
  `modifidate` datetime DEFAULT NULL,
  `deviceInfo` varchar(10000) DEFAULT NULL,
  `two_factor_secret` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`userID`, `firstname`, `lastname`, `fullname`, `email`, `mobile`, `password`, `IP`, `description`, `status`, `registered`, `createdate`, `modifidate`, `deviceInfo`, `two_factor_secret`) VALUES
(21, 'demo', 'Users', NULL, 'demo@gmail.com', '091234567', '$2y$10$efDtfZm1WtEexWeD7NAF9urc1MNuHVcbNcE5FKzV0uh9tPV1IigxK', NULL, NULL, 0, NULL, '2025-04-12 11:31:18', '2025-04-13 14:36:48', NULL, NULL),
(22, 'demo2', 'Users', NULL, 'demo2@gmail.com', '0912345671', '$2y$10$SIb5CvL8z/e/Eto6pdKJie7rywsyVpV6NS3F947Bo9oGPgY6z6pEe', NULL, NULL, 0, NULL, '2025-04-12 11:33:11', '2025-04-20 14:38:53', NULL, NULL),
(23, 'demo3', 'Users', NULL, 'demo3@gmail.com', '091234567', '$2y$10$oj1PJ07yqIp5rPYGGXl6W.w8z04yrxmGIwflz0Gvjv/lJomqkxPXi', NULL, NULL, 0, NULL, '2025-04-12 11:33:16', '2025-04-13 14:38:51', NULL, NULL),
(24, 'ss', '223ss', NULL, 'sonitsp0709@yahoo.com', '34343', '$2y$10$RKus4E8NWXWE1/E14mir7eP0JIwn4tj0R9va/ZFu0MpcBZlm68u2y', NULL, NULL, 0, NULL, '2025-04-12 11:57:53', '2025-04-13 18:06:44', NULL, NULL),
(25, '2322', 'sơn', NULL, 'sonitsp0709@yahoo.com', '343432', '$2y$10$6ccZ5hnDRGHlDiIWr9iaNuh53K.86pr.ygkpdJygfWpIDo0SGc/oK', NULL, NULL, 0, NULL, '2025-04-12 19:08:24', '2025-04-12 19:08:41', NULL, NULL),
(26, 'Ngọc Sơn', 'Trần', NULL, 'tnsonpro@gmail.com', '0916196652', '$2y$10$UYX2kqShBOxd1ds1FRzIG.SFDUcTuOuB4qySh81SYaz1A25VfMsLC', NULL, NULL, 0, NULL, '2025-04-13 17:32:25', '2025-04-13 17:32:47', NULL, NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`),
  ADD KEY `userID` (`userID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
