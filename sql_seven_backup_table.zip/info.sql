-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th8 12, 2025 lúc 09:39 PM
-- Phiên bản máy phục vụ: 10.11.13-MariaDB-cll-lve
-- Phiên bản PHP: 8.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `bsgsfviz_seven_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `info`
--

CREATE TABLE `info` (
  `infoID` int(11) NOT NULL,
  `infoDate` datetime NOT NULL,
  `infoName` varchar(255) NOT NULL,
  `infoNumber` varchar(25) NOT NULL,
  `infoEmail` varchar(50) NOT NULL,
  `infoContent` varchar(2000) NOT NULL,
  `infoDescription` varchar(1000) NOT NULL,
  `Status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Info-thong tin';

--
-- Đang đổ dữ liệu cho bảng `info`
--

INSERT INTO `info` (`infoID`, `infoDate`, `infoName`, `infoNumber`, `infoEmail`, `infoContent`, `infoDescription`, `Status`) VALUES
(11, '2025-06-29 20:16:46', 'sơn22', '0912', 'ex@gmail.com', 'tt2', 'Đăng ký thông tin', 1),
(12, '2025-06-29 20:17:19', 'sơn', '0912', 'ex@gmail.com', 'tt', 'Đăng ký thông tin', 1),
(13, '2024-04-21 19:26:02', 's', '091', 'ex@gmail.com', 'tt2', 'Đăng ký thông tin', 0),
(14, '2024-05-14 22:13:29', 'Nvl ', '0912', 'ex@gmail.com', 'Tt3', 'Đăng ký thông tin2', 1),
(15, '2024-04-21 19:34:57', 'Nvl ', '0912', 'ex@gmail.com', 'Tt3', 'Đăng ký thông tin', 0),
(16, '2024-04-21 19:36:13', 's', '091', 'ex@gmail.com', 'tt5', 'Đăng ký thông tin', 0),
(17, '2024-04-21 19:40:28', 's', '091', 'ex@gmail.com', 'tt6', 'Đăng ký thông tin', 0),
(18, '2024-05-14 22:13:40', 'Nvl ', '091333', 'ex@gmail.com', 'Tt16', 'Đăng ký thông tin', 1),
(19, '2024-05-14 22:13:44', 'Bảy', '097555', 'ex07@gmail.com', '07 test đăng ký 20 khách', 'Đăng ký thông tin', 1),
(20, '2024-05-04 09:36:21', 's', '091', 'ex1@gmail.com', 'ttt55', 'Đăng ký thông tin', 0),
(21, '2024-05-04 09:36:39', 's', '091', 'ex2@gmail.com', '222tt', 'Đăng ký thông tin', 0),
(22, '2024-05-04 09:36:52', 's', '091', 'ex3@gmail.com', '343434', 'Đăng ký thông tin', 0),
(23, '2024-05-04 09:38:54', 's', '091', 'ex4@gmail.com', '444', 'Đăng ký thông tin', 0),
(24, '2024-05-14 22:15:26', 'ss', '091', 'ex22@gmail.com', '222t14', 'Đăng ký thông tin', 0),
(25, '2024-09-17 08:37:14', 'Mai Anh', '0968299219', 'luumaianh219@gmail.com', 'báo giá tour city ', 'Đăng ký thông tin', 0),
(26, '2025-03-23 17:49:30', 's', '091', 'tnsonpro@gmail.com', 'tesst', 'Đăng ký thông tin', 0),
(27, '2025-03-23 17:51:22', 's', '091', 'tnsonpro@gmail.com', 'tesst', 'Đăng ký thông tin', 0),
(28, '2025-03-23 18:01:01', 's', '091', 'tnsonpro@gmail.com', 'tesst2', 'Đăng ký thông tin', 0),
(29, '2025-03-23 18:04:08', 's', '091', 'tnsonpro@gmail.com', 'tesst22', 'Đăng ký thông tin', 0),
(30, '2025-03-23 18:07:20', 's', '091', 'tnsonpro@gmail.com', 'tesst222', 'Đăng ký thông tin', 0),
(31, '2025-03-23 18:12:49', 's', '091', 'tnsonpro@gmail.com', 'tesst2223', 'Đăng ký thông tin', 0),
(32, '2025-03-23 18:29:55', 's', '091', 'tnsonpro@gmail.com', 'tesst22234', 'Đăng ký thông tin', 0),
(33, '2025-03-23 18:35:01', 's', '091', 'tnsonpro@gmail.com', 'tesst222345', 'Đăng ký thông tin', 0),
(34, '2025-03-23 18:38:52', 's', '091', 'tnsonpro@gmail.com', 'tesst2223455', 'Đăng ký thông tin', 0),
(35, '2025-06-06 23:18:17', 'Nguyễn Văn A', '0123456789', 'nguyenvana@example.com', '{&quot;product&quot;:&quot;Laptop&quot;,&quot;quantity&quot;:2,&quot;price&quot;:15000000}', 'Khách hàng muốn giao hàng trong giờ hành chính.', 0),
(36, '2025-06-06 23:22:45', 'Nguyễn Văn A', '0123456789', 'nguyenvana@example.com', '{&quot;product&quot;:&quot;Laptop&quot;,&quot;productID&quot;:101,&quot;imageURL&quot;:&quot;https://example.com/images/laptop.jpg&quot;,&quot;quantity&quot;:2,&quot;price&quot;:15000000,&quot;totalPrice&quot;:30000000,&quot;sessionID&quot;:&quot;abc123xyz&quot;,&quot;orderNumber&quot;:&quot;ORD202506061430&quot;}', 'Khách hàng muốn giao hàng trong giờ hành chính.', 0),
(37, '2025-06-06 23:28:12', 'son', '0916', 'tson@gmail.com', '{&quot;product&quot;:&quot;2 tours selected&quot;,&quot;quantity&quot;:4,&quot;totalPrice&quot;:510,&quot;sessionID&quot;:&quot;llareoflu6&quot;,&quot;orderNumber&quot;:&quot;ORD202506062328&quot;}', 'test1', 0),
(38, '2025-06-06 23:33:49', 'son', '0916', 'tson@gmail.com', '{&quot;product&quot;:&quot;2 tours selected&quot;,&quot;quantity&quot;:4,&quot;totalPrice&quot;:510,&quot;sessionID&quot;:&quot;6otxbd9w5k&quot;,&quot;orderNumber&quot;:&quot;ORD202506062333&quot;}', 'test1', 0);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`infoID`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `info`
--
ALTER TABLE `info`
  MODIFY `infoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
