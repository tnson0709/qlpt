/**
 * store/repository.ts
 * Repository generic cho các entity: CRUD + list + clone.
 */

import { BaseEntity } from './models'
import { bulkPutItems, deleteItem, getAll, getItem, putItem, IDBStoreName } from './db'

/**
 * createId
 * Tạo id duy nhất tối giản.
 */
export function createId(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}_${Date.now().toString(36).slice(-4)}`
}

/**
 * Repository
 * Tập hợp các hàm thao tác với store cụ thể.
 */
export function Repository<T extends BaseEntity>(store: IDBStoreName) {
  return {
    /**
     * list
     * Lấy toàn bộ dữ liệu.
     */
    async list(): Promise<T[]> {
      return getAll<T>(store)
    },
    /**
     * get
     * Lấy một bản ghi theo id.
     */
    async get(id: string): Promise<T | undefined> {
      return getItem<T>(store, id)
    },
    /**
     * save
     * Lưu bản ghi, tự tăng version.
     */
    async save(item: T): Promise<T> {
      return putItem<T>(store, item)
    },
    /**
     * saveMany
     * Lưu danh sách bản ghi.
     */
    async saveMany(items: T[]): Promise<T[]> {
      return bulkPutItems<T>(store, items)
    },
    /**
     * remove
     * Xóa theo id.
     */
    async remove(id: string): Promise<void> {
      return deleteItem(store, id)
    },
    /**
     * clone
     * Nhân bản bản ghi với id mới và version mới.
     */
    async clone(item: T): Promise<T> {
      const cloned = { ...item, id: createId('clone'), version: 0, updatedAt: Date.now() } as T
      return putItem<T>(store, cloned)
    },
  }
}
