/**
 * store/models.ts
 * Khai báo kiểu dữ liệu cốt lõi cho ứng dụng.
 */

/**
 * BaseEntity
 * Bản ghi cơ sở với id, version, thời điểm cập nhật.
 */
export interface BaseEntity {
    id: string
    version: number
    updatedAt: number
  }
  
  /**
   * RoomStatus
   * Trạng thái phòng.
   */
  export type RoomStatus = 'vacant' | 'occupied' | 'maintenance'
  
  /**
   * Room
   * Dữ liệu phòng.
   */
  export interface Room extends BaseEntity {
    number: string
    name: string
    address: string
    rentPrice: number
    electricPrice: number
    waterPrice: number
    utilities: string[]
    status: RoomStatus
    area?: number
  }
  
  /**
   * Tenant
   * Dữ liệu khách thuê.
   */
  export interface Tenant extends BaseEntity {
    fullName: string
    phone?: string
    email?: string
    note?: string
  }
  
  /**
   * Contract
   * Hợp đồng thuê giữa Room và Tenant.
   */
  export interface Contract extends BaseEntity {
    roomId: string
    tenantId: string
    startDate: string
    endDate?: string
    isOpenEnded?: boolean
    deposit?: number
  }
  
  /**
   * FinanceType
   * Loại giao dịch tài chính.
   */
  export type FinanceType = 'income' | 'expense'
  
  /**
   * FinanceItem
   * Mục thu/chi.
   */
  export interface FinanceItem extends BaseEntity {
    type: FinanceType
    category: string
    amount: number
    date: string
    note?: string
    roomId?: string
    tenantId?: string
  }
  
  /**
   * Settings
   * Thiết lập hệ thống chung.
   */
  export interface Settings extends BaseEntity {
    currency: string
    billingCycle: 'monthly'
    internetFee?: number
    serviceFeePerSqm?: number
  }
  
  /**
   * DashboardStat
   * Thống kê tổng hợp cho Dashboard.
   */
  export interface DashboardStat {
    totalRooms: number
    occupiedRooms: number
    vacantRooms: number
    maintenanceRooms: number
    incomeThisMonth: number
    expenseThisMonth: number
  }
  