/**
 * store/seed.ts
 * Seed dữ liệu mẫu cho lần chạy đầu tiên để trải nghiệm nhanh.
 */

import { Repository } from './repository'
import { Contract, FinanceItem, Room, Tenant } from './models'

/**
 * seedIfEmpty
 * Nếu store rỗng thì thêm dữ liệu mẫu.
 */
export async function seedIfEmpty() {
  const roomRepo = Repository<Room>('rooms')
  const tenantRepo = Repository<Tenant>('tenants')
  const contractRepo = Repository<Contract>('contracts')
  const financeRepo = Repository<FinanceItem>('finance')

  const rooms = await roomRepo.list()
  if (rooms.length === 0) {
    const now = Date.now()
    await roomRepo.saveMany([
      {
        id: 'room_a',
        version: 0,
        updatedAt: now,
        number: 'A101',
        name: 'Phòng A101',
        address: '123 Trần Hưng Đạo, Q1',
        rentPrice: 4500000,
        electricPrice: 3500,
        waterPrice: 15000,
        utilities: ['AirCon', 'Washer'],
        status: 'occupied',
        area: 20,
      },
      {
        id: 'room_b',
        version: 0,
        updatedAt: now,
        number: 'B202',
        name: 'Phòng B202',
        address: '456 Nguyễn Trãi, Q5',
        rentPrice: 3800000,
        electricPrice: 3500,
        waterPrice: 15000,
        utilities: ['Fan'],
        status: 'vacant',
        area: 16,
      },
    ])
  }

  const tenants = await tenantRepo.list()
  if (tenants.length === 0) {
    const now = Date.now()
    await tenantRepo.saveMany([
      { id: 'tenant_1', version: 0, updatedAt: now, fullName: 'Nguyễn Văn A', phone: '0900000001', email: 'a@example.com' },
      { id: 'tenant_2', version: 0, updatedAt: now, fullName: 'Trần Thị B', phone: '0900000002', email: 'b@example.com' },
    ])
  }

  const contracts = await contractRepo.list()
  if (contracts.length === 0) {
    const today = new Date()
    const start = new Date(today.getFullYear(), today.getMonth() - 1, 1) // Hợp đồng bắt đầu tháng trước
    const end = new Date(today.getFullYear(), today.getMonth(), 28) // Kết thúc cuối tháng này
    await contractRepo.saveMany([
      {
        id: 'contract_1',
        version: 0,
        updatedAt: Date.now(),
        roomId: 'room_a',
        tenantId: 'tenant_1',
        startDate: start.toISOString(),
        endDate: end.toISOString(),
        isOpenEnded: false,
        deposit: 2000000,
      },
    ])
  }

  const finance = await financeRepo.list()
  if (finance.length === 0) {
    const now = new Date()
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 5)
    await financeRepo.saveMany([
      {
        id: 'fi_1',
        version: 0,
        updatedAt: Date.now(),
        type: 'income',
        category: 'Rent',
        amount: 4500000,
        date: monthStart.toISOString(),
        note: 'Tiền thuê phòng A101',
        roomId: 'room_a',
        tenantId: 'tenant_1',
      },
      {
        id: 'fi_2',
        version: 0,
        updatedAt: Date.now(),
        type: 'expense',
        category: 'Maintenance',
        amount: 500000,
        date: new Date(now.getFullYear(), now.getMonth(), 10).toISOString(),
        note: 'Sửa ống nước B202',
      },
    ])
  }
}
