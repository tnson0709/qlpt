/**
 * store/db.ts
 * Trình trợ giúp IndexedDB tối giản, tạo database và thao tác CRUD cơ bản.
 */

import { BaseEntity } from './models'

/**
 * IDBStoreName
 * Tên các object store trong IndexedDB.
 */
export type IDBStoreName = 'rooms' | 'tenants' | 'contracts' | 'finance' | 'settings'

const DB_NAME = 'roomie-sync'
const DB_VERSION = 1

/**
 * openDB
 * Mở (và tạo) database, thiết lập object stores khi nâng cấp.
 */
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains('rooms')) db.createObjectStore('rooms', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('tenants')) db.createObjectStore('tenants', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('contracts')) db.createObjectStore('contracts', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('finance')) db.createObjectStore('finance', { keyPath: 'id' })
      if (!db.objectStoreNames.contains('settings')) db.createObjectStore('settings', { keyPath: 'id' })
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

/**
 * tx
 * Tạo transaction tiện ích.
 */
function tx(db: IDBDatabase, stores: IDBStoreName[], mode: IDBTransactionMode = 'readonly') {
  return db.transaction(stores, mode)
}

/**
 * putItem
 * Thêm/cập nhật bản ghi; luôn tăng version để đảm bảo "version mới nhất thắng".
 */
export async function putItem<T extends BaseEntity>(store: IDBStoreName, item: T): Promise<T> {
  const db = await openDB()
  const t = tx(db, [store], 'readwrite')
  const s = t.objectStore(store)

  const merged = { ...item, version: (item.version ?? 0) + 1, updatedAt: Date.now() }
  return new Promise((resolve, reject) => {
    const req = s.put(merged)
    req.onsuccess = () => resolve(merged)
    req.onerror = () => reject(req.error)
  })
}

/**
 * bulkPutItems
 * Ghi nhiều bản ghi cùng lúc, tự tăng version cho từng bản ghi.
 */
export async function bulkPutItems<T extends BaseEntity>(store: IDBStoreName, items: T[]): Promise<T[]> {
  const db = await openDB()
  const t = tx(db, [store], 'readwrite')
  const s = t.objectStore(store)
  const results: T[] = []

  await new Promise<void>((resolve, reject) => {
    t.oncomplete = () => resolve()
    t.onerror = () => reject(t.error)
    items.forEach((it) => {
      const merged = { ...it, version: (it.version ?? 0) + 1, updatedAt: Date.now() }
      const req = s.put(merged)
      req.onsuccess = () => results.push(merged)
    })
  })

  return results
}

/**
 * deleteItem
 * Xóa bản ghi theo id.
 */
export async function deleteItem(store: IDBStoreName, id: string): Promise<void> {
  const db = await openDB()
  const t = tx(db, [store], 'readwrite')
  const s = t.objectStore(store)
  await new Promise<void>((resolve, reject) => {
    const req = s.delete(id)
    req.onsuccess = () => resolve()
    req.onerror = () => reject(req.error)
  })
}

/**
 * getItem
 * Lấy bản ghi theo id.
 */
export async function getItem<T>(store: IDBStoreName, id: string): Promise<T | undefined> {
  const db = await openDB()
  const t = tx(db, [store], 'readonly')
  const s = t.objectStore(store)
  return new Promise<T | undefined>((resolve, reject) => {
    const req = s.get(id)
    req.onsuccess = () => resolve(req.result as T)
    req.onerror = () => reject(req.error)
  })
}

/**
 * getAll
 * Lấy toàn bộ bản ghi của store.
 */
export async function getAll<T>(store: IDBStoreName): Promise<T[]> {
  const db = await openDB()
  const t = tx(db, [store], 'readonly')
  const s = t.objectStore(store)
  return new Promise<T[]>((resolve, reject) => {
    const req = s.getAll()
    req.onsuccess = () => resolve((req.result || []) as T[])
    req.onerror = () => reject(req.error)
  })
}
