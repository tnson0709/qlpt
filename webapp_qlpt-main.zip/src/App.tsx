/**
 * App.tsx
 * Mô-đun định tuyến chính của ứng dụng, bọc AuthProvider và thiết lập các route.
 * Sử dụng HashRouterShim (tự cài) vì react-router (core) không xuất HashRouter.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Router, Route, Routes, Navigate } from 'react-router'
import HomePage from './pages/Home'
import RoomsPage from './pages/Rooms'
import TenantsPage from './pages/Tenants'
import FinancePage from './pages/Finance'
import LoginPage from './pages/Login'
import SettingsPage from './pages/Settings'
import AppLayout from './layouts/AppLayout'
import { AuthProvider, useAuth } from './hooks/useAuth'

/**
 * HashRouterShim
 * Router dựa trên hash (#/path) tự cài bằng cách bọc Router (core) + lắng nghe 'hashchange'.
 * - Đảm bảo tương thích với anchor href="#/path" của Sidebar.
 * - Cung cấp navigator push/replace để Navigate hoạt động.
 */
const HashRouterShim: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  /** Lấy path hiện tại từ window.location.hash */
  const getPath = () => {
    if (typeof window === 'undefined') return '/'
    const raw = window.location.hash || ''
    const path = raw.replace(/^#/, '')
    return path || '/'
  }

  /** Chuyển 'to' (string | Partial<LocationLike>) thành path string */
  const toPath = (to: any): string => {
    if (typeof to === 'string') return to || '/'
    const pathname = to?.pathname ?? '/'
    const search = to?.search ?? ''
    const hash = to?.hash ?? ''
    return `${pathname}${search}${hash}` || '/'
  }

  /** State location (đơn giản hóa) để truyền cho Router */
  const [pathname, setPathname] = useState<string>(getPath())

  useEffect(() => {
    // Khởi tạo pathname ban đầu
    setPathname(getPath())

    // Nếu chưa có hash, gán về "/"
    if (typeof window !== 'undefined' && !window.location.hash) {
      window.location.hash = '/'
      setPathname('/')
    }

    const onHash = () => {
      const newPath = getPath()
      setPathname(newPath)
    }

    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  /** Tạo location-like object phù hợp cho Router core */
  const locationLike = useMemo(
    () =>
      ({
        pathname,
        search: '',
        hash: '',
        state: null,
        key: String(Date.now()),
      } as any),
    [pathname]
  )

  /** Navigator tối thiểu để Navigate hoạt động (push/replace/go/createHref) */
  const navigatorLike = useMemo(
    () =>
      ({
        push: (to: any) => {
          const path = toPath(to)
          window.location.hash = path.startsWith('/') ? path : `/${path}`
        },
        replace: (to: any) => {
          const path = toPath(to)
          const full = `#${path.startsWith('/') ? path : `/${path}`}`
          // replace hash mà không thêm vào history stack
          window.location.replace(full)
        },
        go: (n: number) => window.history.go(n),
        createHref: (to: any) => {
          const path = toPath(to)
          return `#${path.startsWith('/') ? path : `/${path}`}`
        },
      } as any),
    []
  )

  return (
    <Router location={locationLike} navigator={navigatorLike}>
      {children}
    </Router>
  )
}

/**
 * RoleGuard
 * Bảo vệ route theo quyền. Admin xem tất cả; user có thể bị hạn chế nếu cần.
 * Dùng <Navigate> để tránh điều hướng trong quá trình render bằng useNavigate().
 */
function RoleGuard({
  children,
  allow = ['admin', 'user'],
}: {
  children: React.ReactNode
  allow?: Array<'admin' | 'user'>
}) {
  const { user } = useAuth()

  // Chưa đăng nhập -> về trang Login
  if (!user) {
    return <Navigate to="/login" replace />
  }

  // Không đủ quyền -> đưa về Dashboard
  if (!allow.includes(user.role)) {
    return <Navigate to="/" replace />
  }

  return <>{children}</>
}

/**
 * App
 * Bọc AuthProvider + HashRouterShim + định nghĩa các tuyến.
 */
export default function App() {
  return (
    <AuthProvider>
      <HashRouterShim>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/"
            element={
              <RoleGuard allow={['admin', 'user']}>
                <AppLayout />
              </RoleGuard>
            }
          >
            <Route index element={<HomePage />} />
            <Route
              path="rooms"
              element={
                <RoleGuard allow={['admin', 'user']}>
                  <RoomsPage />
                </RoleGuard>
              }
            />
            <Route
              path="tenants"
              element={
                <RoleGuard allow={['admin', 'user']}>
                  <TenantsPage />
                </RoleGuard>
              }
            />
            <Route
              path="finance"
              element={
                <RoleGuard allow={['admin', 'user']}>
                  <FinancePage />
                </RoleGuard>
              }
            />
            <Route
              path="settings"
              element={
                <RoleGuard allow={['admin']}>
                  <SettingsPage />
                </RoleGuard>
              }
            />
          </Route>
        </Routes>
      </HashRouterShim>
    </AuthProvider>
  )
}
