export interface Room {
  id: string;
  number: string;
  name: string;
  address: string;
  price: number;
  electricityPrice: number;
  waterPrice: number;
  status: 'vacant' | 'occupied' | 'maintenance';
  amenities: string[];
  area: number;
}

export interface Tenant {
  id: string;
  name: string;
  phone: string;
  email: string;
  idNumber: string;
  contractId?: string;
}

export interface Contract {
  id: string;
  roomId: string;
  tenantId: string;
  startDate: string;
  endDate?: string; // undefined means indefinite
  deposit: number;
  monthlyRent: number;
  status: 'active' | 'terminated' | 'expired';
}

export interface Transaction {
  id: string;
  date: string;
  type: 'income' | 'expense';
  category: string;
  amount: number;
  description: string;
  roomId?: string;
  tenantId?: string;
  contractId?: string;
}

export type UserRole = 'admin' | 'staff';

export interface User {
  id: string;
  username: string;
  role: UserRole;
}
