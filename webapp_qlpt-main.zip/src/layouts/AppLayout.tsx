/**
 * layouts/AppLayout.tsx
 * Khung giao diện chung: Sidebar + Header + Outlet.
 */

import React from 'react'
import { Outlet } from 'react-router'
import { Sidebar } from '../shared/Sidebar'
import { HeaderBar } from '../shared/HeaderBar'

/**
 * AppLayout
 * Bố cục 2 cột với Header cố định.
 */
const AppLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900">
      <div className="flex">
        <Sidebar />
        <div className="flex-1 flex flex-col min-h-screen">
          <HeaderBar />
          <main className="p-6">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  )
}

export default AppLayout
