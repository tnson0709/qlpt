/**
 * utils/print.ts
 * Hỗ trợ in một khu vực cụ thể (nội dung HTML) qua cửa sổ mới.
 */

/**
 * printHtml
 * Mở cửa sổ mới chứa html và gọi print.
 */
export function printHtml(html: string, title = 'Print') {
    const win = window.open('', '_blank', 'width=900,height=700')
    if (!win) return
    win.document.open()
    win.document.write(`<!doctype html>
  <html>
  <head>
  <meta charset="utf-8" />
  <title>${title}</title>
  <style>
    body { font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; color: #111; }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #e5e7eb; padding: 8px; text-align: left; }
    h1,h2,h3 { margin: 8px 0; }
  </style>
  </head>
  <body>
  ${html}
  <script>window.onload = () => { window.print(); setTimeout(() => window.close(), 500); }</script>
  </body>
  </html>`)
    win.document.close()
  }
  