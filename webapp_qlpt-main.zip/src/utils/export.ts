/**
 * utils/export.ts
 * Xuất/nhập CSV đơn giản.
 */

/**
 * toCSV
 * Chuyển mảng object thành CSV.
 */
export function toCSV<T extends Record<string, any>>(rows: T[]): string {
    if (!rows.length) return ''
    const headers = Object.keys(rows[0])
    const lines = [
      headers.join(','),
      ...rows.map((r) =>
        headers
          .map((h) => {
            const cell = r[h] ?? ''
            const needsQuote = [',', '"', '\n'].some((ch) => String(cell).includes(ch))
            const escaped = String(cell).replace(/"/g, '""')
            return needsQuote ? `"${escaped}"` : escaped
          })
          .join(',')
      ),
    ]
    return lines.join('\n')
  }
  
  /**
   * downloadCSV
   * Tải xuống file CSV.
   */
  export function downloadCSV(csv: string, filename = 'export.csv') {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    URL.revokeObjectURL(url)
  }
  
  /**
   * parseCSV
   * Parse CSV tối giản (không xử lý toàn bộ edge case), phù hợp dữ liệu export từ toCSV.
   */
  export function parseCSV(csv: string): Record<string, string>[] {
    const lines = csv.trim().split(/\r?\n/)
    if (lines.length === 0) return []
    const headers = splitCsvLine(lines[0])
    const data: Record<string, string>[] = []
    for (let i = 1; i < lines.length; i++) {
      const cols = splitCsvLine(lines[i])
      const row: Record<string, string> = {}
      headers.forEach((h, idx) => (row[h] = cols[idx] ?? ''))
      data.push(row)
    }
    return data
  }
  
  /**
   * splitCsvLine
   * Tách một dòng CSV, hỗ trợ dấu ngoặc kép.
   */
  function splitCsvLine(line: string): string[] {
    const out: string[] = []
    let cur = ''
    let inQuotes = false
    for (let i = 0; i < line.length; i++) {
      const ch = line[i]
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') {
          cur += '"'
          i++
        } else {
          inQuotes = !inQuotes
        }
      } else if (ch === ',' && !inQuotes) {
        out.push(cur)
        cur = ''
      } else {
        cur += ch
      }
    }
    out.push(cur)
    return out
  }
  