/**
 * utils/format.ts
 * Hàm định dạng giá tiền, ngày tháng.
 */

/**
 * formatCurrency
 * Định dạng tiền tệ theo VNĐ mặc định hoặc theo currency truyền vào.
 */
export function formatCurrency(amount: number, currency = 'VND'): string {
    try {
      return new Intl.NumberFormat('vi-VN', { style: 'currency', currency }).format(amount)
    } catch {
      return `${amount.toLocaleString('vi-VN')} ${currency}`
    }
  }
  
  /**
   * formatDate
   * Định dạng ngày ngắn gọn.
   */
  export function formatDate(iso?: string): string {
    if (!iso) return ''
    const d = new Date(iso)
    return d.toLocaleDateString('vi-VN')
  }
  
  /**
   * daysBetween
   * Số ngày giữa 2 thời điểm (iso).
   */
  export function daysBetween(aIso: string, bIso: string): number {
    const a = new Date(aIso).getTime()
    const b = new Date(bIso).getTime()
    return Math.round((b - a) / (1000 * 60 * 60 * 24))
  }
  
  /**
   * isWithinDays
   * Kiểm tra một ngày có nằm trong n ngày tới so với hôm nay.
   */
  export function isWithinDays(targetIso: string, days: number): boolean {
    const now = new Date()
    const target = new Date(targetIso)
    const diff = Math.round((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    return diff >= 0 && diff <= days
  }
  