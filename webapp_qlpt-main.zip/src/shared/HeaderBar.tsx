/**
 * shared/HeaderBar.tsx
 * Thanh tiêu đề hiển thị người dùng và thao tác nhanh.
 */

import React from 'react'
import { useAuth } from '../hooks/useAuth'
import { Button } from '../components/ui/button'
import { LogOut } from 'lucide-react'

/**
 * HeaderBar
 * Header đơn giản với nút đăng xuất.
 */
export const HeaderBar: React.FC = () => {
  const { user, logout } = useAuth()
  return (
    <header className="h-[56px] border-b border-neutral-200 bg-white flex items-center justify-between px-4">
      <div className="font-semibold">Roomie Sync Manager</div>
      <div className="flex items-center gap-3">
        {user && (
          <div className="text-sm text-neutral-600">
            Xin chào, <span className="font-medium">{user.name}</span> — <span className="uppercase">{user.role}</span>
          </div>
        )}
        <Button variant="outline" className="bg-transparent" onClick={logout}>
          <LogOut className="mr-2 h-4 w-4" />
          Đăng xuất
        </Button>
      </div>
    </header>
  )
}
