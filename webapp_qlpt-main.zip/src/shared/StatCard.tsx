/**
 * shared/StatCard.tsx
 * Thẻ hiển thị chỉ số ngắn gọn.
 */

import React from 'react'

/**
 * StatCardProps
 * Props cho StatCard.
 */
export interface StatCardProps {
  title: string
  value: string
  hint?: string
  accent?: 'green' | 'blue' | 'red' | 'amber'
}

/**
 * StatCard
 * Hiển thị chỉ số với màu nhấn.
 */
export const StatCard: React.FC<StatCardProps> = ({ title, value, hint, accent = 'blue' }) => {
  const color =
    accent === 'green'
      ? 'bg-emerald-50 text-emerald-700'
      : accent === 'red'
      ? 'bg-rose-50 text-rose-700'
      : accent === 'amber'
      ? 'bg-amber-50 text-amber-700'
      : 'bg-sky-50 text-sky-700'
  return (
    <div className={`rounded-lg border border-neutral-200 p-4 bg-white`}>
      <div className="text-xs text-neutral-500">{title}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
      {hint && <div className={`mt-2 text-xs px-2 py-1 rounded ${color}`}>{hint}</div>}
    </div>
  )
}
