/**
 * shared/Sidebar.tsx
 * Sidebar điều hướng chính.
 */

import React from 'react'
import { BarChart3, Home, Settings, Users, Building2, Wallet, ChevronLeft, ChevronRight } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'

/**
 * NavItem
 * Một item điều hướng ở Sidebar.
 */
const NavItem: React.FC<{ href: string; icon: React.ReactNode; label: string; collapsed?: boolean }> = ({ href, icon, label, collapsed }) => {
  // Lấy hash hiện tại, nếu rỗng thì là trang chủ
  const currentHash = typeof window !== 'undefined' ? window.location.hash.replace('#', '') || '/' : '/';
  const active = currentHash === href;
  return (
    <a
      href={`#${href}`}
      className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
        active ? 'bg-neutral-200 text-neutral-900' : 'text-neutral-700 hover:bg-neutral-100'
      }`}
      aria-label={label}
    >
      <span className="w-5 h-5">{icon}</span>
      {!collapsed && <span className="text-sm font-medium">{label}</span>}
    </a>
  )
}

/**
 * Sidebar
 * Cột trái menu và thông tin ngắn gọn.
 */
export const Sidebar: React.FC = () => {
  const { user } = useAuth()
  const [collapsed, setCollapsed] = React.useState(false)
  return (
    <aside
      className={`border-r border-neutral-200 min-h-screen bg-white p-4 flex flex-col transition-all duration-200 ${
        collapsed ? 'w-[64px]' : 'w-[240px]'
      }`}
    >
      <div className={`flex items-center gap-2 mb-6 ${collapsed ? 'justify-center' : ''}`}>
        <img
          src="https://pub-cdn.sider.ai/u/U0Y3HGA0O48/web-coder/68a02d4b38697d89a1ffa609/resource/00457d7e-8061-4b01-a16e-5d9813277e50.jpg"
          className="object-cover w-8 h-8 rounded"
        />
        {!collapsed && (
          <div>
            <div className="font-semibold">Roomie Sync</div>
            <div className="text-xs text-neutral-500">Manager</div>
          </div>
        )}
      </div>

      <nav className="flex flex-col gap-1">
        <NavItem href="/" icon={<Home size={18} />} label="Dashboard" collapsed={collapsed} />
        <NavItem href="/rooms" icon={<Building2 size={18} />} label="Phòng trọ" collapsed={collapsed} />
        <NavItem href="/tenants" icon={<Users size={18} />} label="Khách thuê" collapsed={collapsed} />
        <NavItem href="/finance" icon={<Wallet size={18} />} label="Tài chính" collapsed={collapsed} />
        {user?.role === 'admin' && (
          <NavItem href="/settings" icon={<Settings size={18} />} label="Cài đặt" collapsed={collapsed} />
        )}
      </nav>

      <div className={`mt-auto text-xs text-neutral-500 flex items-center gap-2 ${collapsed ? 'justify-center' : ''}`}>
        <BarChart3 size={14} />
        {!collapsed && <span>v1.0.0</span>}
        <button
          className="ml-auto p-1 rounded hover:bg-neutral-100"
          aria-label={collapsed ? 'Mở rộng menu' : 'Thu gọn menu'}
          onClick={() => setCollapsed((v) => !v)}
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>
    </aside>
  )
}
