/**
 * shared/StatusBadge.tsx
 * Badge trạng thái phòng.
 */

import React from 'react'
import { RoomStatus } from '../store/models'

/**
 * StatusBadge
 * Hiển thị badge theo trạng thái phòng.
 */
export const StatusBadge: React.FC<{ status: RoomStatus }> = ({ status }) => {
  const map: Record<RoomStatus, { text: string; cls: string }> = {
    vacant: { text: 'Trống', cls: 'bg-neutral-100 text-neutral-700' },
    occupied: { text: 'Đã thuê', cls: 'bg-emerald-100 text-emerald-700' },
    maintenance: { text: 'Sửa chữa', cls: 'bg-amber-100 text-amber-800' },
  }
  const s = map[status]
  return <span className={`text-xs px-2 py-1 rounded ${s.cls}`}>{s.text}</span>
}
