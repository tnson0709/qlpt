/**
 * hooks/useAuth.tsx
 * Cung cấp ngữ cảnh xác thực đơn giản (localStorage) với vai trò admin/user.
 */

import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'

/**
 * UserRole
 * Vai trò của người dùng: admin hoặc user.
 */
export type UserRole = 'admin' | 'user'

/**
 * AuthUser
 * Kiểu thông tin người dùng đăng nhập tối thiểu.
 */
export interface AuthUser {
  id: string
  name: string
  role: UserRole
}

/**
 * AuthContextValue
 * API của ngữ cảnh xác thực.
 */
interface AuthContextValue {
  user: AuthUser | null
  login: (user: AuthUser) => void
  logout: () => void
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

/**
 * useAuth
 * Hook lấy dữ liệu xác thực.
 */
export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}

/**
 * genId
 * Tạo ID ngẫu nhiên ngắn gọn.
 */
function genId(prefix = 'u'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`
}

/**
 * AuthProvider
 * Bọc ứng dụng, quản lý state người dùng trong localStorage.
 */
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null)

  useEffect(() => {
    try {
      const raw = localStorage.getItem('roomie_auth')
      if (raw) setUser(JSON.parse(raw))
    } catch {
      // ignore
    }
  }, [])

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      login: (u) => {
        const next = { ...u, id: u.id || genId('u') }
        setUser(next)
        localStorage.setItem('roomie_auth', JSON.stringify(next))
      },
      logout: () => {
        setUser(null)
        localStorage.removeItem('roomie_auth')
      },
    }),
    [user]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
