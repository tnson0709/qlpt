/**
 * pages/Rooms.tsx
 * Quản lý phòng trọ: danh sách, thêm/sửa (Dialog), xóa, nhân bản, in ấn.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog'
import { Repository, createId } from '../store/repository'
import { Room, RoomStatus } from '../store/models'
import { StatusBadge } from '../shared/StatusBadge'
import { formatCurrency } from '../utils/format'

import { Download, Copy, Edit2, Plus, Printer, Trash2 } from 'lucide-react'

import { toCSV, downloadCSV } from '../utils/export'
import { printHtml } from '../utils/print'
import { useAuth } from '../hooks/useAuth'

/**
 * RoomFormProps
 * Props cho form thêm/sửa phòng.
 */
interface RoomFormProps {
  open: boolean
  onOpenChange: (v: boolean) => void
  initial?: Room | null
  onSaved: () => void
}

/**
 * RoomForm
 * Dialog form để thêm/sửa một phòng.
 */
const RoomForm: React.FC<RoomFormProps> = ({ open, onOpenChange, initial, onSaved }) => {
  const repo = Repository<Room>('rooms')
  const [data, setData] = useState<Room>(
    initial || {
      id: createId('room'),
      version: 0,
      updatedAt: Date.now(),
      number: '',
      name: '',
      address: '',
      rentPrice: 0,
      electricPrice: 0,
      waterPrice: 0,
      utilities: [],
      status: 'vacant',
      area: 0,
    }
  )

  useEffect(() => {
    if (initial) setData(initial)
  }, [initial])

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target
    setData((d) => ({ ...d, [id]: id.includes('Price') || id === 'area' ? Number(value || 0) : value }))
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await repo.save({ ...data })
    onSaved()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[720px]">
        <DialogHeader>
          <DialogTitle>{initial ? 'Sửa phòng' : 'Thêm phòng'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label htmlFor="number">Số phòng</Label>
            <Input id="number" value={data.number} onChange={onChange} required />
          </div>
          <div className="space-y-1">
            <Label htmlFor="name">Tên phòng</Label>
            <Input id="name" value={data.name} onChange={onChange} required />
          </div>
          <div className="space-y-1 col-span-2">
            <Label htmlFor="address">Địa chỉ</Label>
            <Input id="address" value={data.address} onChange={onChange} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="rentPrice">Giá thuê</Label>
            <Input id="rentPrice" type="number" value={data.rentPrice} onChange={onChange} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="electricPrice">Giá điện</Label>
            <Input id="electricPrice" type="number" value={data.electricPrice} onChange={onChange} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="waterPrice">Giá nước</Label>
            <Input id="waterPrice" type="number" value={data.waterPrice} onChange={onChange} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="area">Diện tích (m²)</Label>
            <Input id="area" type="number" value={data.area || 0} onChange={onChange} />
          </div>
          <div className="space-y-1 col-span-2">
            <Label htmlFor="utilities">Tiện ích (phân tách bởi dấu ,)</Label>
            <Input
              id="utilities"
              value={data.utilities.join(', ')}
              onChange={(e) => setData((d) => ({ ...d, utilities: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) }))}
            />
          </div>

          <div className="col-span-2 flex items-center justify-between mt-2">
            <div className="flex gap-2">
              {(['vacant', 'occupied', 'maintenance'] as RoomStatus[]).map((st) => (
                <Button
                  key={st}
                  type="button"
                  variant={data.status === st ? 'default' : 'outline'}
                  className={data.status === st ? '' : 'bg-transparent'}
                  onClick={() => setData((d) => ({ ...d, status: st }))}
                >
                  {st === 'vacant' ? 'Trống' : st === 'occupied' ? 'Đã thuê' : 'Sửa chữa'}
                </Button>
              ))}
            </div>
            <Button type="submit">Lưu</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/**
 * RoomsPage
 * Liệt kê phòng và thao tác.
 */
const RoomsPage: React.FC = () => {
  const repo = Repository<Room>('rooms')
  const { user } = useAuth()
  const [list, setList] = useState<Room[]>([])
  const [open, setOpen] = useState(false)
  const [editItem, setEditItem] = useState<Room | null>(null)

  const reload = async () => {
    const data = await repo.list()
    setList(data)
  }

  useEffect(() => {
    reload()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const exportCSV = () => {
    downloadCSV(toCSV(list), 'rooms.csv')
  }

  const printList = () => {
    const html = `
      <h2>Danh sách phòng</h2>
      <table>
        <thead>
          <tr>
            <th>Số</th><th>Tên</th><th>Địa chỉ</th><th>Trạng thái</th><th>Giá thuê</th>
          </tr>
        </thead>
        <tbody>
          ${list
            .map(
              (r) =>
                `<tr><td>${r.number}</td><td>${r.name}</td><td>${r.address}</td><td>${r.status}</td><td>${r.rentPrice}</td></tr>`
            )
            .join('')}
        </tbody>
      </table>
    `
    printHtml(html, 'Danh sách phòng')
  }

  const onDelete = async (id: string) => {
    if (user?.role !== 'admin') return
    if (!confirm('Xóa phòng này?')) return
    await repo.remove(id)
    reload()
  }

  const onDuplicate = async (r: Room) => {
    await repo.clone(r)
    reload()
  }

  const totalRent = useMemo(() => list.reduce((s, r) => s + (r.rentPrice || 0), 0), [list])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Quản lý phòng</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-transparent" onClick={exportCSV}>
            <Download className="mr-2 h-4 w-4" />
            Xuất CSV
          </Button>
          <Button onClick={printList}>
            <Printer className="mr-2 h-4 w-4" />
            In danh sách
          </Button>
          <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setEditItem(null) }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Thêm phòng
              </Button>
            </DialogTrigger>
            <RoomForm open={open} onOpenChange={setOpen} initial={editItem} onSaved={reload} />
          </Dialog>
        </div>
      </div>

      <div className="bg-white border border-neutral-200 rounded-lg overflow-x-auto">
        <table className="min-w-[960px] w-full text-sm">
          <thead>
            <tr className="text-neutral-600">
              <th className="text-left py-2 px-3 border-b">Số</th>
              <th className="text-left py-2 px-3 border-b">Tên</th>
              <th className="text-left py-2 px-3 border-b">Địa chỉ</th>
              <th className="text-left py-2 px-3 border-b">Trạng thái</th>
              <th className="text-left py-2 px-3 border-b">Giá thuê</th>
              <th className="text-left py-2 px-3 border-b">Tiện ích</th>
              <th className="text-left py-2 px-3 border-b w-[220px]">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {list.map((r) => (
              <tr key={r.id} className="border-b last:border-b-0">
                <td className="py-2 px-3">{r.number}</td>
                <td className="py-2 px-3">{r.name}</td>
                <td className="py-2 px-3">{r.address}</td>
                <td className="py-2 px-3"><StatusBadge status={r.status} /></td>
                <td className="py-2 px-3">{formatCurrency(r.rentPrice)}</td>
                <td className="py-2 px-3">{r.utilities.join(', ')}</td>
                <td className="py-2 px-3">
                  <div className="flex gap-2">
                    <Button variant="outline" className="bg-transparent" onClick={() => { setEditItem(r); setOpen(true) }}>
                      <Edit2 className="h-4 w-4 mr-2" /> Sửa
                    </Button>
                    <Button variant="outline" className="bg-transparent" onClick={() => onDuplicate(r)}>
                      
<Copy className="h-4 w-4 mr-2" /> Nhân bản

                    </Button>
                    <Button variant="outline" className="bg-transparent" disabled={true}>
                      {/* Chỗ này có thể dùng sau: In phiếu phòng */}
                      <Printer className="h-4 w-4 mr-2" /> In
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-transparent text-rose-600 border-rose-200 hover:text-rose-700"
                      onClick={() => onDelete(r.id)}
                      disabled={user?.role !== 'admin'}
                    >
                      <Trash2 className="h-4 w-4 mr-2" /> Xóa
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr>
                <td className="py-4 px-3 text-neutral-500" colSpan={7}>
                  Chưa có phòng nào. Hãy bấm “Thêm phòng”.
                </td>
              </tr>
            )}
          </tbody>
          <tfoot>
            <tr>
              <td className="py-2 px-3 font-medium" colSpan={4}>
                Tổng giá thuê tham chiếu
              </td>
              <td className="py-2 px-3 font-semibold">{formatCurrency(totalRent)}</td>
              <td colSpan={2}></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}

export default RoomsPage
