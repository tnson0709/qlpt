/**
 * pages/Finance.tsx
 * Quản lý tài chính: thu/chi, nhập/xuất CSV, in ấn.
 */

import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog'
import { Repository, createId } from '../store/repository'
import { FinanceItem } from '../store/models'
import { Download, Plus, Printer, Upload, Trash2 } from 'lucide-react'
import { downloadCSV, parseCSV, toCSV } from '../utils/export'
import { formatCurrency, formatDate } from '../utils/format'
import { printHtml } from '../utils/print'
import { useAuth } from '../hooks/useAuth'

/**
 * FinanceForm
 * Dialog form thêm/sửa giao dịch tài chính.
 */
const FinanceForm: React.FC<{
  open: boolean
  onOpenChange: (v: boolean) => void
  initial?: FinanceItem | null
  onSaved: () => void
}> = ({ open, onOpenChange, initial, onSaved }) => {
  const repo = Repository<FinanceItem>('finance')
  const [data, setData] = useState<FinanceItem>(
    initial || {
      id: createId('fi'),
      version: 0,
      updatedAt: Date.now(),
      type: 'income',
      category: '',
      amount: 0,
      date: new Date().toISOString(),
      note: '',
    }
  )

  useEffect(() => {
    if (initial) setData(initial)
  }, [initial])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await repo.save(data)
    onSaved()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[640px]">
        <DialogHeader>
          <DialogTitle>{initial ? 'Sửa giao dịch' : 'Thêm giao dịch'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Loại</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={data.type === 'income' ? 'default' : 'outline'}
                className={data.type === 'income' ? '' : 'bg-transparent'}
                onClick={() => setData((d) => ({ ...d, type: 'income' }))}
              >
                Thu
              </Button>
              <Button
                type="button"
                variant={data.type === 'expense' ? 'default' : 'outline'}
                className={data.type === 'expense' ? '' : 'bg-transparent'}
                onClick={() => setData((d) => ({ ...d, type: 'expense' }))}
              >
                Chi
              </Button>
            </div>
          </div>
          <div className="space-y-1">
            <Label>Ngày</Label>
            <Input
              type="date"
              value={data.date.slice(0, 10)}
              onChange={(e) => setData((d) => ({ ...d, date: new Date(e.target.value).toISOString() }))}
            />
          </div>
          <div className="space-y-1 col-span-2">
            <Label>Hạng mục</Label>
            <Input value={data.category} onChange={(e) => setData((d) => ({ ...d, category: e.target.value }))} />
          </div>
            <div className="space-y-1">
              <Label>Số tiền</Label>
              <Input
                type="number"
                value={data.amount}
                onChange={(e) => setData((d) => ({ ...d, amount: Number(e.target.value || 0) }))}
              />
            </div>
            <div className="space-y-1">
              <Label>Ghi chú</Label>
              <Input value={data.note} onChange={(e) => setData((d) => ({ ...d, note: e.target.value }))} />
            </div>
          <div className="col-span-2 flex justify-end">
            <Button type="submit">Lưu</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/**
 * FinancePage
 * Liệt kê giao dịch thu/chi với tổng hợp.
 */
const FinancePage: React.FC = () => {
  const repo = Repository<FinanceItem>('finance')
  const { user } = useAuth()
  const [list, setList] = useState<FinanceItem[]>([])
  const [open, setOpen] = useState(false)
  const [editItem, setEditItem] = useState<FinanceItem | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const reload = async () => {
    const data = await repo.list()
    // Sắp xếp theo ngày mới nhất
    data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    setList(data)
  }

  useEffect(() => {
    reload()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const totalIncome = useMemo(() => list.filter((i) => i.type === 'income').reduce((s, i) => s + i.amount, 0), [list])
  const totalExpense = useMemo(() => list.filter((i) => i.type === 'expense').reduce((s, i) => s + i.amount, 0), [list])
  const balance = totalIncome - totalExpense

  const exportCSV = () => downloadCSV(toCSV(list), 'finance.csv')

  const printReport = () => {
    const rows = list
      .map((i) => `<tr><td>${i.type}</td><td>${i.category}</td><td>${formatDate(i.date)}</td><td>${i.amount}</td><td>${i.note || ''}</td></tr>`)
      .join('')
    const html = `
      <h2>Báo cáo thu/chi</h2>
      <table>
        <thead><tr><th>Loại</th><th>Hạng mục</th><th>Ngày</th><th>Số tiền</th><th>Ghi chú</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <h3>Tổng thu: ${totalIncome} — Tổng chi: ${totalExpense} — Số dư: ${balance}</h3>
    `
    printHtml(html, 'Báo cáo tài chính')
  }

  const onImport = () => fileRef.current?.click()

  const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const text = await file.text()
    const rows = parseCSV(text)
    const items: FinanceItem[] = rows.map((r) => ({
      id: r.id || createId('fi'),
      version: Number(r.version || 0),
      updatedAt: Number(r.updatedAt || Date.now()),
      type: (r.type as any) || 'income',
      category: r.category || '',
      amount: Number(r.amount || 0),
      date: r.date || new Date().toISOString(),
      note: r.note || '',
      roomId: r.roomId || undefined,
      tenantId: r.tenantId || undefined,
    }))
    await repo.saveMany(items)
    reload()
    e.target.value = ''
  }

  const onDelete = async (id: string) => {
    if (user?.role !== 'admin') return
    if (!confirm('Xóa giao dịch này?')) return
    await repo.remove(id)
    reload()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Quản lý tài chính</h1>
        <div className="flex gap-2">
          <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={onFileChange} />
          <Button variant="outline" className="bg-transparent" onClick={onImport}>
            <Upload className="mr-2 h-4 w-4" /> Nhập CSV
          </Button>
          <Button variant="outline" className="bg-transparent" onClick={exportCSV}>
            <Download className="mr-2 h-4 w-4" /> Xuất CSV
          </Button>
          <Button onClick={printReport}>
            <Printer className="mr-2 h-4 w-4" /> In báo cáo
          </Button>
          <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setEditItem(null) }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Thêm giao dịch
              </Button>
            </DialogTrigger>
            <FinanceForm open={open} onOpenChange={setOpen} initial={editItem} onSaved={reload} />
          </Dialog>
        </div>
      </div>

      <div className="bg-white border border-neutral-200 rounded-lg overflow-x-auto">
        <table className="min-w-[960px] w-full text-sm">
          <thead>
            <tr className="text-neutral-600">
              <th className="text-left py-2 px-3 border-b">Loại</th>
              <th className="text-left py-2 px-3 border-b">Hạng mục</th>
              <th className="text-left py-2 px-3 border-b">Ngày</th>
              <th className="text-left py-2 px-3 border-b">Số tiền</th>
              <th className="text-left py-2 px-3 border-b">Ghi chú</th>
              <th className="text-left py-2 px-3 border-b w-[140px]">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {list.map((i) => (
              <tr key={i.id} className="border-b last:border-b-0">
                <td className="py-2 px-3">{i.type === 'income' ? 'Thu' : 'Chi'}</td>
                <td className="py-2 px-3">{i.category}</td>
                <td className="py-2 px-3">{formatDate(i.date)}</td>
                <td className="py-2 px-3">{formatCurrency(i.amount)}</td>
                <td className="py-2 px-3">{i.note}</td>
                <td className="py-2 px-3">
                  <div className="flex gap-2">
                    <Button variant="outline" className="bg-transparent" onClick={() => { setEditItem(i); setOpen(true) }}>
                      Sửa
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-transparent text-rose-600 border-rose-200 hover:text-rose-700"
                      onClick={() => onDelete(i.id)}
                      disabled={user?.role !== 'admin'}
                    >
                      <Trash2 className="h-4 w-4 mr-1" /> Xóa
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {list.length === 0 && (
              <tr>
                <td className="py-4 px-3 text-neutral-500" colSpan={6}>
                  Chưa có giao dịch. Hãy thêm mới hoặc nhập CSV.
                </td>
              </tr>
            )}
          </tbody>
          <tfoot>
            <tr>
              <td className="py-2 px-3 font-medium" colSpan={3}>
                Tổng thu
              </td>
              <td className="py-2 px-3 font-semibold">{formatCurrency(totalIncome)}</td>
              <td colSpan={2}></td>
            </tr>
            <tr>
              <td className="py-2 px-3 font-medium" colSpan={3}>
                Tổng chi
              </td>
              <td className="py-2 px-3 font-semibold">{formatCurrency(totalExpense)}</td>
              <td colSpan={2}></td>
            </tr>
            <tr>
              <td className="py-2 px-3 font-medium" colSpan={3}>
                Số dư
              </td>
              <td className="py-2 px-3 font-semibold">{formatCurrency(balance)}</td>
              <td colSpan={2}></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}

export default FinancePage
