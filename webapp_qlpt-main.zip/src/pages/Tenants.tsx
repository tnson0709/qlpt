/**
 * pages/Tenants.tsx
 * Quản lý khách thuê và hợp đồng cơ bản.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '../components/ui/dialog'
import { Repository, createId } from '../store/repository'
import { Contract, Room, Tenant } from '../store/models'
import { Download, Edit2, Plus, Printer, Trash2 } from 'lucide-react'
import { toCSV, downloadCSV } from '../utils/export'
import { printHtml } from '../utils/print'
import { useAuth } from '../hooks/useAuth'
import { formatDate } from '../utils/format'

// Giá nhà nước mẫu (có thể chỉnh lại cho phù hợp)
const ELECTRIC_PRICE = 3000 // VND/kWh
const WATER_PRICE = 18000 // VND/m3

/**
 * ReceiptDialog
 * Dialog sinh phiếu thu tháng cho các khách thuê còn hợp đồng.
 */
const ReceiptDialog: React.FC<{
  open: boolean
  onOpenChange: (v: boolean) => void
  contracts: Contract[]
  tenants: Tenant[]
  rooms: Room[]
}> = ({ open, onOpenChange, contracts, tenants, rooms }) => {
  // Chỉ lấy hợp đồng còn hạn hoặc vô thời hạn
  const validContracts = useMemo(() => {
    const now = new Date()
    return contracts.filter(
      (c) =>
        c.isOpenEnded ||
        (c.endDate && new Date(c.endDate) >= now)
    )
  }, [contracts])

  // State cho từng hợp đồng
  const [rows, setRows] = useState<
    Array<{
      contractId: string
      electricStart: number
      electricEnd: number
      waterStart: number
      waterEnd: number
      electric: number
      water: number
      rent: number
      internet: number
      service: number
      other: number
    }>
  >([])

  useEffect(() => {
    // Khởi tạo dữ liệu cho từng hợp đồng
    setRows(
      validContracts.map((c) => ({
        contractId: c.id,
        electricStart: 0,
        electricEnd: 0,
        waterStart: 0,
        waterEnd: 0,
        electric: 0,
        water: 0,
        rent: 0,
        internet: 0,
        service: 0,
        other: 0,
      }))
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, validContracts.length])

  // Tìm tenant và room theo id
  const findTenant = (id?: string) => tenants.find((t) => t.id === id)
  const findRoom = (id?: string) => rooms.find((r) => r.id === id)

  // Xử lý nhập chỉ số điện/nước và tính tiền
  const handleInput = (idx: number, field: string, value: number) => {
    setRows((prev) => {
      const next = [...prev]
      next[idx] = { ...next[idx], [field]: value }
      // Nếu là chỉ số điện/nước thì tính lại tiền
      if (field === 'electricStart' || field === 'electricEnd') {
        const kwh = Math.max(0, next[idx].electricEnd - next[idx].electricStart)
        next[idx].electric = kwh * ELECTRIC_PRICE
      }
      if (field === 'waterStart' || field === 'waterEnd') {
        const m3 = Math.max(0, next[idx].waterEnd - next[idx].waterStart)
        next[idx].water = m3 * WATER_PRICE
      }
      return next
    })
  }

  // Tính tổng tiền từng dòng
  const calcTotal = (row: typeof rows[number]) =>
    (row.rent || 0) +
    (row.electric || 0) +
    (row.water || 0) +
    (row.internet || 0) +
    (row.service || 0) +
    (row.other || 0)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[1100px]">
        <DialogHeader>
          <DialogTitle>Sinh phiếu thu tháng</DialogTitle>
        </DialogHeader>
        <div className="overflow-x-auto">
          <table className="min-w-[1000px] w-full text-sm border">
            <thead>
              <tr className="bg-neutral-100">
                <th className="p-2 border">Khách thuê</th>
                <th className="p-2 border">Phòng</th>
                <th className="p-2 border">Tiền nhà</th>
                <th className="p-2 border">Điện (kWh)</th>
                <th className="p-2 border">Tiền điện</th>
                <th className="p-2 border">Nước (m³)</th>
                <th className="p-2 border">Tiền nước</th>
                <th className="p-2 border">Internet</th>
                <th className="p-2 border">Dịch vụ</th>
                <th className="p-2 border">Khác</th>
                <th className="p-2 border">Tổng tiền</th>
              </tr>
            </thead>
            <tbody>
              {validContracts.map((c, idx) => {
                const tenant = findTenant(c.tenantId)
                const room = findRoom(c.roomId)
                const row = rows[idx] || {}
                return (
                  <tr key={c.id} className="border-b">
                    <td className="p-2 border">{tenant?.fullName || c.tenantId}</td>
                    <td className="p-2 border">{room?.name || c.roomId}</td>
                    <td className="p-2 border">
                      <Input
                        type="number"
                        value={row.rent || ''}
                        onChange={(e) => handleInput(idx, 'rent', Number(e.target.value || 0))}
                        placeholder="Tiền nhà"
                        className="w-[100px]"
                      />
                    </td>
                    <td className="p-2 border">
                      <div className="flex gap-1 items-center">
                        <Input
                          type="number"
                          value={row.electricStart}
                          onChange={(e) => handleInput(idx, 'electricStart', Number(e.target.value || 0))}
                          placeholder="Đầu"
                          className="w-[60px]"
                        />
                        <span>-</span>
                        <Input
                          type="number"
                          value={row.electricEnd}
                          onChange={(e) => handleInput(idx, 'electricEnd', Number(e.target.value || 0))}
                          placeholder="Cuối"
                          className="w-[60px]"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          className="ml-2 px-2 py-1"
                          onClick={() => {
                            const kwh = Math.max(0, row.electricEnd - row.electricStart)
                            handleInput(idx, 'electric', kwh * ELECTRIC_PRICE)
                          }}
                        >
                          Tính
                        </Button>
                      </div>
                    </td>
                    <td className="p-2 border">
                      <Input
                        type="number"
                        value={row.electric}
                        onChange={(e) => handleInput(idx, 'electric', Number(e.target.value || 0))}
                        placeholder="Tiền điện"
                        className="w-[90px]"
                      />
                    </td>
                    <td className="p-2 border">
                      <div className="flex gap-1 items-center">
                        <Input
                          type="number"
                          value={row.waterStart}
                          onChange={(e) => handleInput(idx, 'waterStart', Number(e.target.value || 0))}
                          placeholder="Đầu"
                          className="w-[60px]"
                        />
                        <span>-</span>
                        <Input
                          type="number"
                          value={row.waterEnd}
                          onChange={(e) => handleInput(idx, 'waterEnd', Number(e.target.value || 0))}
                          placeholder="Cuối"
                          className="w-[60px]"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          className="ml-2 px-2 py-1"
                          onClick={() => {
                            const m3 = Math.max(0, row.waterEnd - row.waterStart)
                            handleInput(idx, 'water', m3 * WATER_PRICE)
                          }}
                        >
                          Tính
                        </Button>
                      </div>
                    </td>
                    <td className="p-2 border">
                      <Input
                        type="number"
                        value={row.water}
                        onChange={(e) => handleInput(idx, 'water', Number(e.target.value || 0))}
                        placeholder="Tiền nước"
                        className="w-[90px]"
                      />
                    </td>
                    <td className="p-2 border">
                      <Input
                        type="number"
                        value={row.internet}
                        onChange={(e) => handleInput(idx, 'internet', Number(e.target.value || 0))}
                        placeholder="Internet"
                        className="w-[90px]"
                      />
                    </td>
                    <td className="p-2 border">
                      <Input
                        type="number"
                        value={row.service}
                        onChange={(e) => handleInput(idx, 'service', Number(e.target.value || 0))}
                        placeholder="Dịch vụ"
                        className="w-[90px]"
                      />
                    </td>
                    <td className="p-2 border">
                      <Input
                        type="number"
                        value={row.other}
                        onChange={(e) => handleInput(idx, 'other', Number(e.target.value || 0))}
                        placeholder="Khác"
                        className="w-[90px]"
                      />
                    </td>
                    <td className="p-2 border font-semibold text-blue-700">
                      {calcTotal(row).toLocaleString()}
                    </td>
                  </tr>
                )
              })}
              {validContracts.length === 0 && (
                <tr>
                  <td className="p-4 text-neutral-500" colSpan={11}>
                    Không có khách thuê nào có hợp đồng còn hạn hoặc vô thời hạn.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end mt-4">
          <DialogClose asChild>
            <Button variant="outline">Đóng</Button>
          </DialogClose>
        </div>
      </DialogContent>
    </Dialog>
  )
}

/**
 * TenantForm
 * Dialog form thêm/sửa khách thuê.
 */
const TenantForm: React.FC<{
  open: boolean
  onOpenChange: (v: boolean) => void
  initial?: Tenant | null
  onSaved: () => void
}> = ({ open, onOpenChange, initial, onSaved }) => {
  const repo = Repository<Tenant>('tenants')
  const [data, setData] = useState<Tenant>(
    initial || { id: createId('tenant'), version: 0, updatedAt: Date.now(), fullName: '', phone: '', email: '', note: '' }
  )

  useEffect(() => {
    if (initial) setData(initial)
  }, [initial])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await repo.save(data)
    onSaved()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[640px]">
        <DialogHeader>
          <DialogTitle>{initial ? 'Sửa khách thuê' : 'Thêm khách thuê'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3">
          <div className="space-y-1 col-span-2">
            <Label htmlFor="fullName">Họ tên</Label>
            <Input
              id="fullName"
              value={data.fullName}
              onChange={(e) => setData((d) => ({ ...d, fullName: e.target.value }))}
              required
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="phone">SĐT</Label>
            <Input id="phone" value={data.phone} onChange={(e) => setData((d) => ({ ...d, phone: e.target.value }))} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="email">Email</Label>
            <Input id="email" value={data.email} onChange={(e) => setData((d) => ({ ...d, email: e.target.value }))} />
          </div>
          <div className="space-y-1 col-span-2">
            <Label htmlFor="note">Ghi chú</Label>
            <Input id="note" value={data.note} onChange={(e) => setData((d) => ({ ...d, note: e.target.value }))} />
          </div>
          <div className="col-span-2 flex justify-end">
            <Button type="submit">Lưu</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/**
 * ContractForm
 * Dialog tạo/sửa hợp đồng đơn giản.
 */
const ContractForm: React.FC<{
  open: boolean
  onOpenChange: (v: boolean) => void
  initial?: Contract | null
  onSaved: () => void
  tenants: Tenant[]
  rooms: Room[]
}> = ({ open, onOpenChange, initial, onSaved, tenants, rooms }) => {
  const repo = Repository<Contract>('contracts')
  const [data, setData] = useState<Contract>(
    initial || {
      id: createId('contract'),
      version: 0,
      updatedAt: Date.now(),
      roomId: rooms[0]?.id || '',
      tenantId: tenants[0]?.id || '',
      startDate: new Date().toISOString(),
      endDate: '',
      isOpenEnded: false,
      deposit: 0,
    }
  )

  useEffect(() => {
    if (initial) setData(initial)
  }, [initial])

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await repo.save(data)
    onSaved()
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[640px]">
        <DialogHeader>
          <DialogTitle>{initial ? 'Sửa hợp đồng' : 'Tạo hợp đồng'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={onSubmit} className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Phòng</Label>
            <select
              className="border rounded h-9 px-2 text-sm"
              value={data.roomId}
              onChange={(e) => setData((d) => ({ ...d, roomId: e.target.value }))}
            >
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name} ({r.number})
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1">
            <Label>Khách thuê</Label>
            <select
              className="border rounded h-9 px-2 text-sm"
              value={data.tenantId}
              onChange={(e) => setData((d) => ({ ...d, tenantId: e.target.value }))}
            >
              {tenants.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.fullName}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1">
            <Label>Bắt đầu</Label>
            <Input
              type="date"
              value={data.startDate.slice(0, 10)}
              onChange={(e) => setData((d) => ({ ...d, startDate: new Date(e.target.value).toISOString() }))}
            />
          </div>
          <div className="space-y-1">
            <Label>Kết thúc (nếu có)</Label>
            <Input
              type="date"
              value={data.endDate ? data.endDate.slice(0, 10) : ''}
              onChange={(e) => setData((d) => ({ ...d, endDate: e.target.value ? new Date(e.target.value).toISOString() : '' }))}
            />
          </div>
          <div className="space-y-1">
            <Label>Tiền cọc</Label>
            <Input
              type="number"
              value={data.deposit || 0}
              onChange={(e) => setData((d) => ({ ...d, deposit: Number(e.target.value || 0) }))}
            />
          </div>
          <div className="space-y-1 flex items-end">
            <label className="inline-flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={!!data.isOpenEnded}
                onChange={(e) => setData((d) => ({ ...d, isOpenEnded: e.target.checked, endDate: e.target.checked ? '' : d.endDate }))}
              />
              Vô thời hạn
            </label>
          </div>
          <div className="col-span-2 flex justify-end">
            <Button type="submit">Lưu</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}

/**
 * TenantsPage
 * Liệt kê khách thuê + hợp đồng, kèm thao tác cơ bản.
 */
const TenantsPage: React.FC = () => {
  const tenantRepo = Repository<Tenant>('tenants')
  const roomRepo = Repository<Room>('rooms')
  const contractRepo = Repository<Contract>('contracts')
  const { user } = useAuth()

  const [tenants, setTenants] = useState<Tenant[]>([])
  const [rooms, setRooms] = useState<Room[]>([])
  const [contracts, setContracts] = useState<Contract[]>([])

  const [openTenant, setOpenTenant] = useState(false)
  const [editTenant, setEditTenant] = useState<Tenant | null>(null)

  const [openContract, setOpenContract] = useState(false)
  const [editContract, setEditContract] = useState<Contract | null>(null)

  const [selectedTenantId, setSelectedTenantId] = useState<string | null>(null)

  const [openReceipt, setOpenReceipt] = useState(false)

  const reload = async () => {
    const [t, r, c] = await Promise.all([tenantRepo.list(), roomRepo.list(), contractRepo.list()])
    setTenants(t)
    setRooms(r)
    setContracts(c)
  }

  useEffect(() => {
    reload()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const exportCSV = () => downloadCSV(toCSV(tenants), 'tenants.csv')

  const printList = () => {
    const html = `
      <h2>Danh sách khách thuê</h2>
      <table>
        <thead><tr><th>Họ tên</th><th>SĐT</th><th>Email</th></tr></thead>
        <tbody>
          ${tenants.map((t) => `<tr><td>${t.fullName}</td><td>${t.phone || ''}</td><td>${t.email || ''}</td></tr>`).join('')}
        </tbody>
      </table>
    `
    // eslint-disable-next-line @typescript-eslint/no-floating-promises
    printHtml(html, 'Khách thuê')
  }

  const onDeleteTenant = async (id: string) => {
    if (user?.role !== 'admin') return
    if (!confirm('Xóa khách thuê này?')) return
    await tenantRepo.remove(id)
    reload()
  }

  const onDeleteContract = async (id: string) => {
    if (user?.role !== 'admin') return
    if (!confirm('Xóa hợp đồng này?')) return
    await contractRepo.remove(id)
    reload()
  }

  const onEditContract = (contract: Contract) => {
    setEditContract(contract)
    setOpenContract(true)
  }

  const onCloneContract = async (contract: Contract) => {
    const clone: Contract = {
      ...contract,
      id: createId('contract'),
      version: 0,
      updatedAt: Date.now(),
    }
    await contractRepo.save(clone)
    reload()
  }

  const printContract = (contract: Contract) => {
    const tenant = findTenant(contract.tenantId)
    const room = findRoom(contract.roomId)
    const html = `
      <h2>Hợp đồng thuê phòng</h2>
      <p><strong>Khách thuê:</strong> ${tenant?.fullName || contract.tenantId}</p>
      <p><strong>Phòng:</strong> ${room?.name || contract.roomId}</p>
      <p><strong>Bắt đầu:</strong> ${formatDate(contract.startDate)}</p>
      <p><strong>Kết thúc:</strong> ${contract.isOpenEnded ? 'Vô thời hạn' : formatDate(contract.endDate)}</p>
      <p><strong>Tiền cọc:</strong> ${contract.deposit}</p>
    `
    printHtml(html, 'Hợp đồng thuê phòng')
  }

  const findRoom = (id?: string) => rooms.find((r) => r.id === id)
  const findTenant = (id?: string) => tenants.find((t) => t.id === id)

  const filteredContracts = useMemo(() => {
    if (!selectedTenantId) return contracts
    return contracts.filter((c) => c.tenantId === selectedTenantId)
  }, [contracts, selectedTenantId])

  const contractRows = useMemo(() => {
    return filteredContracts.map((c) => ({
      id: c.id,
      room: findRoom(c.roomId)?.name || c.roomId,
      tenant: findTenant(c.tenantId)?.fullName || c.tenantId,
      start: formatDate(c.startDate),
      end: c.isOpenEnded ? 'Vô thời hạn' : formatDate(c.endDate),
      contract: c,
    }))
  }, [filteredContracts, rooms, tenants])

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Quản lý khách thuê</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-transparent" onClick={exportCSV}>
            <Download className="mr-2 h-4 w-4" /> Xuất CSV
          </Button>
          <Button onClick={printList}>
            <Printer className="mr-2 h-4 w-4" /> In danh sách
          </Button>
          <Button variant="outline" className="bg-transparent" onClick={() => setOpenReceipt(true)}>
            <Printer className="mr-2 h-4 w-4" /> Sinh phiếu thu tháng
          </Button>
          <Dialog open={openTenant} onOpenChange={(v) => { setOpenTenant(v); if (!v) setEditTenant(null) }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Thêm khách
              </Button>
            </DialogTrigger>
            <TenantForm open={openTenant} onOpenChange={setOpenTenant} initial={editTenant} onSaved={reload} />
          </Dialog>
          <Dialog open={openContract} onOpenChange={(v) => { setOpenContract(v); if (!v) setEditContract(null) }}>
            <DialogTrigger asChild>
              <Button variant="outline" className="bg-transparent">
                <Plus className="mr-2 h-4 w-4" /> Tạo hợp đồng
              </Button>
            </DialogTrigger>
            <ContractForm
              open={openContract}
              onOpenChange={setOpenContract}
              initial={editContract}
              onSaved={reload}
              tenants={tenants}
              rooms={rooms}
            />
          </Dialog>
        </div>
      </div>
      {/* Dialog phiếu thu */}
      <ReceiptDialog
        open={openReceipt}
        onOpenChange={setOpenReceipt}
        contracts={contracts}
        tenants={tenants}
        rooms={rooms}
      />
      <div className="bg-white border border-neutral-200 rounded-lg overflow-x-auto">
        <table className="min-w-[800px] w-full text-sm">
          <thead>
            <tr className="text-neutral-600">
              <th className="text-left py-2 px-3 border-b">Họ tên</th>
              <th className="text-left py-2 px-3 border-b">SĐT</th>
              <th className="text-left py-2 px-3 border-b">Email</th>
              <th className="text-left py-2 px-3 border-b w-[160px]">Thao tác</th>
            </tr>
          </thead>
          <tbody>
            {tenants.map((t) => (
              <tr
                key={t.id}
                className={`border-b last:border-b-0 cursor-pointer ${selectedTenantId === t.id ? 'bg-blue-50' : ''}`}
                onClick={() => setSelectedTenantId(selectedTenantId === t.id ? null : t.id)}
              >
                <td className="py-2 px-3">{t.fullName}</td>
                <td className="py-2 px-3">{t.phone}</td>
                <td className="py-2 px-3">{t.email}</td>
                <td className="py-2 px-3">
                  <div className="flex gap-2">
                    <Button variant="outline" className="bg-transparent" onClick={(e) => { e.stopPropagation(); setEditTenant(t); setOpenTenant(true) }}>
                      <Edit2 className="h-4 w-4 mr-2" /> Sửa
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-transparent text-rose-600 border-rose-200 hover:text-rose-700"
                      onClick={(e) => { e.stopPropagation(); onDeleteTenant(t.id) }}
                      disabled={user?.role !== 'admin'}
                    >
                      <Trash2 className="h-4 w-4 mr-2" /> Xóa
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {tenants.length === 0 && (
              <tr>
                <td className="py-4 px-3 text-neutral-500" colSpan={4}>
                  Chưa có khách thuê. Hãy thêm mới.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="bg-white border border-neutral-200 rounded-lg p-4">
        <div className="text-sm font-medium mb-3 flex items-center justify-between">
          <span>Hợp đồng hiện tại {selectedTenantId ? `(chỉ khách: ${findTenant(selectedTenantId)?.fullName})` : ''}</span>
          <Button variant="outline" className="bg-transparent" onClick={() => setSelectedTenantId(null)}>
            Hiện tất cả
          </Button>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-[720px] w-full text-sm">
            <thead>
              <tr className="text-neutral-600">
                <th className="text-left py-2 border-b">ID</th>
                <th className="text-left py-2 border-b">Phòng</th>
                <th className="text-left py-2 border-b">Khách</th>
                <th className="text-left py-2 border-b">Bắt đầu</th>
                <th className="text-left py-2 border-b">Kết thúc</th>
                <th className="text-left py-2 border-b w-[220px]">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {contractRows.map((c) => (
                <tr key={c.id} className="border-b last:border-b-0">
                  <td className="py-2">#{c.id}</td>
                  <td className="py-2">{c.room}</td>
                  <td className="py-2">{c.tenant}</td>
                  <td className="py-2">{c.start}</td>
                  <td className="py-2">{c.end}</td>
                  <td className="py-2">
                    <div className="flex gap-2">
                      <Button variant="outline" className="bg-transparent" onClick={() => onEditContract(c.contract)}>
                        <Edit2 className="h-4 w-4 mr-2" /> Sửa
                      </Button>
                      <Button
                        variant="outline"
                        className="bg-transparent text-rose-600 border-rose-200 hover:text-rose-700"
                        onClick={() => onDeleteContract(c.id)}
                        disabled={user?.role !== 'admin'}
                      >
                        <Trash2 className="h-4 w-4 mr-2" /> Xóa
                      </Button>
                      <Button variant="outline" className="bg-transparent" onClick={() => onCloneContract(c.contract)}>
                        <Plus className="h-4 w-4 mr-2" /> Nhân bản
                      </Button>
                      <Button variant="outline" className="bg-transparent" onClick={() => printContract(c.contract)}>
                        <Printer className="h-4 w-4 mr-2" /> In
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {contractRows.length === 0 && (
                <tr>
                  <td className="py-4 text-neutral-500" colSpan={6}>
                    Chưa có hợp đồng. Tạo hợp đồng mới.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default TenantsPage
