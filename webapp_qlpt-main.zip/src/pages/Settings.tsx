/**
 * pages/Settings.tsx
 * Thiết lập hệ thống: tiền tệ, chu kỳ tính tiền, đồng bộ hoá (stub).
 */

import React, { useEffect, useState } from 'react'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Repository, createId } from '../store/repository'
import { Settings } from '../store/models'
import { CloudUpload } from 'lucide-react'

/**
 * SettingsPage
 * Lưu và hiển thị thiết lập.
 */
const SettingsPage: React.FC = () => {
  const repo = Repository<Settings>('settings')
  const [data, setData] = useState<Settings | null>(null)

  useEffect(() => {
    ;(async () => {
      const items = await repo.list()
      if (items.length === 0) {
        const def: Settings = {
          id: createId('settings'),
          version: 0,
          updatedAt: Date.now(),
          currency: 'VND',
          billingCycle: 'monthly',
          internetFee: 0,
          serviceFeePerSqm: 0,
        }
        const saved = await repo.save(def)
        setData(saved)
      } else {
        setData(items[0])
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  if (!data) return null

  const onSave = async (e: React.FormEvent) => {
    e.preventDefault()
    const saved = await repo.save(data)
    setData(saved)
    alert('Đã lưu thiết lập.')
  }

  const onSync = async () => {
    // Stub đồng bộ: ở đây có thể gọi API server:
    //  - Gửi version hiện tại
    //  - Nhận diff, merge theo version mới nhất thắng
    //  - Cập nhật local IndexedDB
    // Hiện tại: mô phỏng thành công
    await new Promise((r) => setTimeout(r, 600))
    alert('Đồng bộ thành công (mô phỏng).')
  }

  return (
    <div className="space-y-4 max-w-[680px]">
      <h1 className="text-xl font-semibold">Cài đặt hệ thống</h1>
      <form onSubmit={onSave} className="bg-white border border-neutral-200 rounded-lg p-4 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <Label>Tiền tệ</Label>
            <Input value={data.currency} onChange={(e) => setData({ ...data, currency: e.target.value })} />
          </div>
          <div className="space-y-1">
            <Label>Chu kỳ tính tiền</Label>
            <Input value={data.billingCycle} disabled />
          </div>
          <div className="space-y-1">
            <Label>Phí Internet (tháng)</Label>
            <Input
              type="number"
              value={data.internetFee || 0}
              onChange={(e) => setData({ ...data, internetFee: Number(e.target.value || 0) })}
            />
          </div>
          <div className="space-y-1">
            <Label>Phí DV/m²</Label>
            <Input
              type="number"
              value={data.serviceFeePerSqm || 0}
              onChange={(e) => setData({ ...data, serviceFeePerSqm: Number(e.target.value || 0) })}
            />
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button type="submit">Lưu thiết lập</Button>
          <Button type="button" variant="outline" className="bg-transparent" onClick={onSync}>
            <CloudUpload className="mr-2 h-4 w-4" /> Đồng bộ server
          </Button>
        </div>
      </form>
    </div>
  )
}

export default SettingsPage
