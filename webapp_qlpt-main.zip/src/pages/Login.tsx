/**
 * pages/Login.tsx
 * Màn hình đăng nhập đơn giản, chọn vai trò (admin/user).
 */

import React, { useState } from 'react'
import { useNavigate } from 'react-router'
import { useAuth, UserRole } from '../hooks/useAuth'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { ShieldCheck } from 'lucide-react'

/**
 * LoginPage
 * Cho phép nhập tên hiển thị và chọn vai trò.
 */
const LoginPage: React.FC = () => {
  const [name, setName] = useState('')
  const [role, setRole] = useState<UserRole>('admin')
  const { login } = useAuth()
  const navigate = useNavigate()

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const username = name.trim() || (role === 'admin' ? 'Quản trị' : 'Nhân viên')
    login({ id: '', name: username, role })
    navigate('/')
  }

  return (
    <div className="min-h-screen grid place-items-center bg-neutral-50">
      <form onSubmit={onSubmit} className="bg-white rounded-lg border border-neutral-200 p-6 w-[360px] shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <ShieldCheck className="text-sky-600" />
          <div className="font-semibold">Đăng nhập Roomie Sync</div>
        </div>

        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="name">Tên hiển thị</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="VD: Nguyễn Văn A" />
          </div>
          <div className="space-y-1">
            <Label>Vai trò</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={role === 'admin' ? 'default' : 'outline'}
                className={role === 'admin' ? '' : 'bg-transparent'}
                onClick={() => setRole('admin')}
              >
                Admin
              </Button>
              <Button
                type="button"
                variant={role === 'user' ? 'default' : 'outline'}
                className={role === 'user' ? '' : 'bg-transparent'}
                onClick={() => setRole('user')}
              >
                User
              </Button>
            </div>
          </div>
        </div>

        <Button type="submit" className="w-full mt-5">
          Vào hệ thống
        </Button>
      </form>
    </div>
  )
}

export default LoginPage
