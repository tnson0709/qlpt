/**
 * pages/Home.tsx
 * Dashboard tổng quan: chỉ số, biểu đồ, cảnh báo hợp đồng sắp hết hạn.
 */

import React, { useEffect, useMemo, useState } from 'react'
import { StatCard } from '../shared/StatCard'
import { formatCurrency, formatDate, isWithinDays } from '../utils/format'
import { Repository } from '../store/repository'
import { Contract, DashboardStat, FinanceItem, Room, Tenant } from '../store/models'
import { seedIfEmpty } from '../store/seed'
import { Bar, BarChart, CartesianGrid, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell } from 'recharts'
import { Button } from '../components/ui/button'
import { Download, Printer } from 'lucide-react'
import { downloadCSV, toCSV } from '../utils/export'
import { printHtml } from '../utils/print'

/**
 * useDashboardData
 * Hook tập hợp dữ liệu Dashboard từ IndexedDB.
 */
function useDashboardData() {
  const roomRepo = Repository<Room>('rooms')
  const tenantRepo = Repository<Tenant>('tenants')
  const contractRepo = Repository<Contract>('contracts')
  const financeRepo = Repository<FinanceItem>('finance')

  const [rooms, setRooms] = useState<Room[]>([])
  const [contracts, setContracts] = useState<Contract[]>([])
  const [finance, setFinance] = useState<FinanceItem[]>([])

  useEffect(() => {
    ;(async () => {
      await seedIfEmpty()
      const [r, c, f] = await Promise.all([roomRepo.list(), contractRepo.list(), financeRepo.list()])
      setRooms(r)
      setContracts(c)
      setFinance(f)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const stat: DashboardStat = useMemo(() => {
    const totalRooms = rooms.length
    const occupiedRooms = rooms.filter((r) => r.status === 'occupied').length
    const vacantRooms = rooms.filter((r) => r.status === 'vacant').length
    const maintenanceRooms = rooms.filter((r) => r.status === 'maintenance').length

    const now = new Date()
    const m = now.getMonth()
    const y = now.getFullYear()
    const inMonth = finance.filter((i) => {
      const d = new Date(i.date)
      return d.getMonth() === m && d.getFullYear() === y
    })
    const incomeThisMonth = inMonth.filter((i) => i.type === 'income').reduce((s, i) => s + i.amount, 0)
    const expenseThisMonth = inMonth.filter((i) => i.type === 'expense').reduce((s, i) => s + i.amount, 0)

    return { totalRooms, occupiedRooms, vacantRooms, maintenanceRooms, incomeThisMonth, expenseThisMonth }
  }, [rooms, finance])

  const revenueMonthly = useMemo(() => {
    // Đơn giản hóa: gom 6 tháng gần đây
    const map = new Map<string, { income: number; expense: number }>()
    const now = new Date()
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      map.set(key, { income: 0, expense: 0 })
    }
    finance.forEach((f) => {
      const d = new Date(f.date)
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
      if (map.has(key)) {
        const cur = map.get(key)!
        if (f.type === 'income') cur.income += f.amount
        else cur.expense += f.amount
      }
    })
    return Array.from(map.entries()).map(([name, v]) => ({ name, ...v }))
  }, [finance])

  const expiringContracts = useMemo(() => {
    return contracts
      .filter((c) => c.endDate && (isWithinDays(c.endDate, 14) || isWithinDays(c.endDate, 7) || isWithinDays(c.endDate, 1)))
      .sort((a, b) => new Date(a.endDate!).getTime() - new Date(b.endDate!).getTime())
  }, [contracts])

  return { rooms, contracts, finance, stat, revenueMonthly, expiringContracts }
}

/**
 * HomePage
 * Trang Dashboard với biểu đồ và cảnh báo.
 */
const HomePage: React.FC = () => {
  const { stat, revenueMonthly, expiringContracts } = useDashboardData()

  const exportFinance = async () => {
    const financeRepo = Repository<FinanceItem>('finance')
    const data = await financeRepo.list()
    const csv = toCSV(data)
    downloadCSV(csv, 'finance.csv')
  }

  const printDashboard = () => {
    const html = document.getElementById('printable-dashboard')?.innerHTML || ''
    printHtml(html, 'Báo cáo Dashboard')
  }

  const pieData = [
    { name: 'Thu', value: stat.incomeThisMonth, color: '#22c55e' },
    { name: 'Chi', value: stat.expenseThisMonth, color: '#ef4444' },
  ]

  return (
    <div className="space-y-6" id="printable-dashboard">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Dashboard</h1>
        <div className="flex gap-2">
          <Button variant="outline" className="bg-transparent" onClick={exportFinance}>
            <Download className="mr-2 h-4 w-4" />
            Xuất CSV tài chính
          </Button>
          <Button onClick={printDashboard}>
            <Printer className="mr-2 h-4 w-4" />
            In báo cáo
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          title="Tổng số phòng"
          value={String(stat.totalRooms)}
          hint={`${stat.occupiedRooms} đã thuê • ${stat.vacantRooms} trống • ${stat.maintenanceRooms} sửa chữa`}
          accent="blue"
        />
        <StatCard title="Thu tháng này" value={formatCurrency(stat.incomeThisMonth)} accent="green" />
        <StatCard title="Chi tháng này" value={formatCurrency(stat.expenseThisMonth)} accent="red" />
        <StatCard
          title="Công suất"
          value={`${stat.totalRooms ? Math.round((stat.occupiedRooms / stat.totalRooms) * 100) : 0}%`}
          hint="Tỷ lệ phòng đã thuê"
          accent="amber"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-white border border-neutral-200 rounded-lg p-4 lg:col-span-2">
          <div className="text-sm font-medium mb-2">Doanh thu theo tháng (6 gần nhất)</div>
          <div className="h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueMonthly}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="income" name="Thu" fill="#22c55e" />
                <Bar dataKey="expense" name="Chi" fill="#ef4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="bg-white border border-neutral-200 rounded-lg p-4">
          <div className="text-sm font-medium mb-2">Thu/Chi tháng này</div>
          <div className="h-[260px] grid place-items-center">
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie dataKey="value" data={pieData} nameKey="name" label>
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white border border-neutral-200 rounded-lg p-4">
        <div className="text-sm font-medium mb-3">Cảnh báo hợp đồng sắp hết hạn (1/7/14 ngày)</div>
        {expiringContracts.length === 0 ? (
          <div className="text-sm text-neutral-500">Không có hợp đồng sắp hết hạn.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-[640px] w-full text-sm">
              <thead>
                <tr className="text-neutral-600">
                  <th className="text-left py-2 border-b">Hợp đồng</th>
                  <th className="text-left py-2 border-b">Phòng</th>
                  <th className="text-left py-2 border-b">Khách</th>
                  <th className="text-left py-2 border-b">Bắt đầu</th>
                  <th className="text-left py-2 border-b">Kết thúc</th>
                  <th className="text-left py-2 border-b">Còn lại</th>
                </tr>
              </thead>
              <tbody>
                {expiringContracts.map((c) => {
                  const daysLeft = Math.max(0, Math.round((new Date(c.endDate!).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
                  const color =
                    daysLeft <= 1 ? 'text-rose-600' : daysLeft <= 7 ? 'text-amber-600' : 'text-sky-600'
                  return (
                    <tr key={c.id} className="border-b last:border-b-0">
                      <td className="py-2">#{c.id}</td>
                      <td className="py-2">{c.roomId}</td>
                      <td className="py-2">{c.tenantId}</td>
                      <td className="py-2">{formatDate(c.startDate)}</td>
                      <td className="py-2">{formatDate(c.endDate)}</td>
                      <td className={`py-2 font-medium ${color}`}>{daysLeft} ngày</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

export default HomePage
