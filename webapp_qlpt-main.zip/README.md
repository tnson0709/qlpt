# Roomie Sync Manager

## Memory Bank Structure
- **Phòng trọ (Room)**
  - id, số phòng, tên phòng, địa chỉ, trạng thái, giá thuê, giá điện, giá nước, tiện ích
- **Khách thuê (Tenant)**
  - id, tên, thông tin cá nhân, danh sách hợp đồng thuê
- **Hợp đồng thuê (Contract)**
  - id, phòng, khách thuê, ngày bắt đầu, ngày kết thúc, loại hợp đồng, trạng thái
- **Tài chính (Finance)**
  - id, loại giao dịch (thu/chi), số tiền, phòng, khách thuê, thời gian, ghi chú
- **Công nợ (Debt)**
  - id, phòng, khách thuê, số tiền còn nợ, hạn thanh toán
- **Hóa đơn (Invoice)**
  - id, phòng, khách thuê, kỳ hóa đơn, chi tiết các khoản thu, trạng thái thanh toán
- **Người dùng (User)**
  - id, tên, vai trò (Admin/Nhân viên), thông tin đăng nhập
- **Hệ thống đồng bộ (Sync)**
  - version, trạng thái đồng bộ, lịch sử thay đổi

## Chức năng chính

### 1. Quản lý phòng trọ
- Thông tin phòng: số phòng, tên phòng, địa chỉ
- Giá cả: giá thuê, giá điện, giá nước
- Trạng thái phòng: trống/đã thuê/đang sửa chữa
- Tiện ích đi kèm

### 2. Quản lý khách thuê
- Thông tin cá nhân khách thuê
- Quản lý hợp đồng thuê
- Theo dõi thời hạn thuê (có thời hạn/vô thời hạn)

### 3. Quản lý tài chính
- Thu: tiền thuê, tiền điện, tiền nước, tiền internet, phí dịch vụ (theo m²)
- Chi: các khoản phí vận hành, bảo trì
- Theo dõi công nợ
- Xuất hóa đơn tự động

### 4. Tính năng hệ thống
- Đăng nhập và phân quyền (Admin/Nhân viên)
- Lưu trữ dữ liệu local (IndexDB)
- Đồng bộ hóa với server
- Xuất/nhập dữ liệu Excel
- In ấn báo cáo PDF

### 5. Dashboard thống kê
- Biểu đồ doanh thu (tháng/quý/năm)
- Thống kê thu/chi
- Cảnh báo hợp đồng sắp hết hạn (1/7/14 ngày)
- Báo cáo công suất phòng

## Quy tắc hệ thống
- Giao diện dạng dialog cho thêm/sửa
- CRUD + nhân bản + in ấn
- Chu kỳ tính tiền: hàng tháng
- Giải quyết xung đột đồng bộ theo version mới nhất


